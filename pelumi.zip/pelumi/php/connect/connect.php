<?php

    $connect = new mysqli(
        "localhost",
        "root",
        "",
        "pelumi_project"
    );

?>
