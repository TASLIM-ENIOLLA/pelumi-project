<?php

    include "../../init.php";

    if(isset($_POST)){
        $fullname = $_POST["fullname"];
        $email = $_POST["email"];
        $message = $_POST["message"];

        $query = $connect -> query(
            "INSERT INTO contact_us SET full_name = '$fullname', email_address = '$email', message = '$message'"
        );

        if($query){
            echo "success";
        }
        else{
            echo "error";
        }
    }

?>
