<?php

	include "../../init.php";

	if(isset($_POST) && !empty($_POST)){
		$id = employerIDGenerator();
		$email_address = filterInput($_POST["email_address"]);
		$phone_number = filterInput($_POST["phone_number"]);
		$location = filterInput($_POST["location"]);
		$password = filterInput($_POST["password"]);
		$c_password = filterInput($_POST["c_password"]);
		$agreement = filterInput($_POST["agreement"]);
		$which = filterInput($_POST["which"]);


		if($which == "employer"){
			$company_name = filterInput($_POST["company_name"]);
			$CAC_number = filterInput($_POST["CAC_number"]);
		}
		else{
			$f_name = filterInput($_POST["f_name"]);
			$l_name = filterInput($_POST["l_name"]);
		}

		if(strlen($email_address) < 1 && strlen($email_address) > 100){
			echo "Email address too long.";
		}
		elseif(!preg_match("/\d/", $phone_number)){
			echo "Phone number contains unwanted characters.";
		}
		elseif($password !== $c_password){
			echo "Passwords do not match.";
		}
		elseif($which == "employer" && strlen($f_name) > 50){
			echo "First name too long.";	
		}
		elseif($which == "employer" && strlen($l_name) > 50){
			echo "Last name too long.";	
		}
		else{
			if($which == "employer"){
				$password = md5($password);

				$query = $connect -> query(
					"INSERT INTO employer SET id = '$id', company_name = '$company_name', phone_number = '$phone_number', location = '$location', password = '$password', CAC_number = '$CAC_number', email_address = '$email_address'"
				);

				if($query){
					setcookie(
						"JOB",
						json_encode(
							array(
								"id" => $id,
								"type" => "employer"
							)
						)
					);
					echo "success";
				}
				else{
					echo "Something went wrong. Try again.";
				}
			}
			else{
				$password = md5($password);

				$query = $connect -> query(
					"INSERT INTO employee SET id = '$id', f_name  = '$f_name', l_name  = '$l_name', phone_number = '$phone_number', location = '$location', password = '$password', email_address = '$email_address'"
				);

				if($query){
					setcookie(
						"JOB",
						json_encode(
							array(
								"id" => $id,
								"type" => "employee",
								"name" => $f_name
							)
						)
					);
					echo "success";
				}
				else{
					echo "Something went wrong. Try again.";
				}
			}
		}
	}

?>