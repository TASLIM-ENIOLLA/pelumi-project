<?php

    include "../../init.php";

    if(isset($_POST)){
        $email = $_POST["email"];
        $qualification = $_POST["qualification"];

        $query = $connect -> query(
            "INSERT INTO newsletter SET email_address = '$email', qualification = '$qualification'"
        );

        if($query){
            echo "success";
        }
        else{
            echo "error";
        }
    }

?>
