<?php

    class JobDetails{
        public function __construct(){
            if(isset($_GET["job_id"])){
                global $connect;

                $job_id = $_GET["job_id"];

                $query = $connect -> query(
                    "SELECT * FROM jobs INNER JOIN employer ON `jobs`.`employer_id` = `employer`.`id` WHERE `jobs`.`id` = '$job_id'"
                );

                if($query && $query -> num_rows > 0){
                    $this -> job_info = $query -> fetch_assoc();
                }
                else{
                    $this -> job_info = NULL;
                }
            }
            else{
                $this -> job_info = NULL;
            }
        }
    }

    $JobDetails = new JobDetails();

?>
