<?php

    // class Testimonials{
    //     public function __construct(){
    //         global $connect;
    //         $this -> tst = [];
    //
    //         $query = $connect -> query(
    //             "SELECT * FROM testimonials"
    //         );
    //
    //         if($query -> num_rows > 0){
    //             while($row = $query -> fetch_assoc()){
    //                 array_push(
    //                     $this -> tst,
    //                     $row
    //                 );
    //             }
    //         }
    //     }
    //
    //     private $userImagesFolder = "images/users/";
    //
    //     public function renderTestimonialsForHomePage(){
    //         $result = '';
    //
    //         if(count($this -> tst) > 0){
    //             foreach($this -> tst as $tst){
    //                 $result .= '
    //                     <div class="col-sm-4 col-md-4">
    //                          <div class="item">
    //                               <div class="tst-image">
    //                                    <img src="' . $this -> userImagesFolder . $tst["user_id"] . "/" . '" class="img-responsive" alt="">
    //                               </div>
    //                               <div class="tst-author">
    //                                    <h4>Jackson</h4>
    //                                    <span>Shopify Developer</span>
    //                               </div>
    //                               <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam voluptas, facilis adipisci dolorem exercitationem nemo aut error impedit repudiandae iusto.</p>
    //                               <div class="tst-rating">
    //                                    <i class="fa fa-star"></i>
    //                                    <i class="fa fa-star"></i>
    //                                    <i class="fa fa-star"></i>
    //                                    <i class="fa fa-star"></i>
    //                                    <i class="fa fa-star"></i>
    //                               </div>
    //                          </div>
    //                     </div>
    //                 ';
    //             }
    //         }
    //         else{
    //             $result .= '
    //                 <div class = "mx-auto col-11 my-4 p-5 bg-light shadow-sm rounded bold text-secondary text-c">
    //                     Oops! Coming soon.
    //                 </div>
    //             ';
    //         }
    //     }
    // }

?>
