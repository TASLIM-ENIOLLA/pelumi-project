<?php

    class Jobs{
        public function __construct(){
            global $connect;
            $this -> jobs = [];

            $query = $connect -> query(
                "SELECT * FROM `jobs` LIMIT 3"
            );

            if($query -> num_rows > 0){
                while($row = $query -> fetch_assoc()){
                    array_push(
                        $this -> jobs,
                        $row
                    );
                }
            }
        }

        private $jobImagesFolder = "admin/assets/";
        private $defaultImage = "admin/assets/img/default.png";

        public function renderJobsForHomePage(){
            $result = '';

            if(count($this -> jobs) > 0){
                foreach($this -> jobs as $job){
                    if(!file_exists($this -> jobImagesFolder . "/" . $job["image"])){
                        $this -> jobImagesFolder = $this -> defaultImage;
                    }
                    else{
                        $this -> jobImagesFolder = $this -> jobImagesFolder . "/" . $job["image"];
                    }

                    $result .= '
                        <div class="col-md-4 col-sm-6 col-md-6">
                             <div class="courses-thumb courses-thumb-secondary border rounded">
                                  <div class="courses-top">
                                       <div class="courses-image">
                                            <img src="' . $this -> jobImagesFolder . '" class="img-responsive mx-auto" alt="">
                                       </div>
                                       <div class="courses-date">
                                            <span title="Posted on"><i class="fa fa-calendar"></i> ' . date("M d, Y", strtotime($job["timestamp"])) . '</span>
                                            <span title="Location"><i class="fa fa-map-marker"></i> ' . $job["location"] . '</span>
                                            <span title="Type"><i class="fa fa-file"></i> ' . $job["job_type"] . '</span>
                                       </div>
                                  </div>

                                  <div class="courses-detail">
                                       <h3><a href="job-details.php?job_id=' . $job["id"] . '">' . $job["title"] . '</a></h3>

                                       <p class="lead"><strong>₦' . $job["payment"] . '</strong></p>

                                       <p >Sector: ' . $job["job_category"] . '</p>
                                  </div>

                                  <div class="courses-info">
                                       <a href="job-details.php?job_id=' . $job["id"] . '" class="section-btn btn btn-primary btn-block">View Details</a>
                                  </div>
                             </div>
                        </div>
                    ';
                }
            }
            else{
                $result .= '
                    <div class = "mx-auto col-11 my-4 p-5 bg-light shadow-sm rounded bold text-secondary text-c">
                        Oops! We are undergoing maintenance. Please check back again!
                    </div>
                ';
            }

            return $result;
        }
    }

    $Jobs = new Jobs()

?>
