<?php

    include "../../init.php";

    if(isset($_GET["job_search_query"])){
        $job_search_query = $_GET["job_search_query"];
        $job_search_query_constraint = $_GET["job_search_query_constraint"];

        $query = $connect -> query(
            "SELECT * FROM jobs WHERE $job_search_query_constraint LIKE '%{$job_search_query}%' LIMIT 3"
        );

        if(strlen($job_search_query) > 0 && $query && $query -> num_rows > 0){
            $res = [];
            while($row = $query -> fetch_assoc()){
                array_push($res, $row);
            }
            echo json_encode($res);
        }
        else{
            echo json_encode([]);
        }
    }

?>
