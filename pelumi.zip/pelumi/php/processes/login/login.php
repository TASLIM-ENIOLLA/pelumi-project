<?php

	if(isset($_POST) && count($_POST) > 0){
		if($_POST["which"] == "employer"){
			$cac_number = $_POST["cac_number"];
			$password = md5($_POST["password"]);

			$query = $connect -> query(
				"SELECT * FROM employer WHERE CAC_number = '$cac_number' AND password = '$password'"
			);

			if($query && $query -> num_rows > 0){
				$verification_message =  "Login successful. Redirecting in a moment.";
				$res = $query -> fetch_assoc();
				$id = $res["id"];
				$email_address = $res["email_address"];
				setcookie(
					"MP-HIRES",
					json_encode(
						array(
							"id" => $id,
							"email_address" => $email_address,
							"which" => "employer"
						)
					),
					time() + (365 * 24 * 3600),
					"/"
				);
				header("Location: admin/index.php");
			}
			else{
				$verification_message =  "Login credentials seem incorrect.";
			}
		}
		else{
			$email_address = $_POST["email_address"];
			$password = md5($_POST["password"]);

			$query = $connect -> query(
				"SELECT * FROM employee WHERE email_address = '$email_address' AND password = '$password'"
			);

			if($query && $query -> num_rows > 0){
				$verification_message =  "Login successful. Redirecting in a moment.";
				$res = $query -> fetch_assoc();
				$id = $res["id"];
				$f_name = $res["f_name"];
				$email_address = $res["email_address"];
				setcookie(
					"MP-HIRES",
					json_encode(
						array(
							"id" => $id,
							"email_address" => $email_address,
							"f_name" => $f_name,
							"which" => "employee"
						)
					),
					time() + (365 * 24 * 3600),
					"/"
				);
				header("Location: admin/index.php");
			}
			else{
				$verification_message =  "Login credentials seem incorrect.";
			}
		}
	}

?>
