<?php

    function filterInput($var){
        global $connect;
        $var = trim($var);
        $var = htmlspecialchars($var);
        $var = stripslashes($var);
        $var = strip_tags($var);
        $var = mysqli_real_escape_string($connect, $var);

        return $var;
    }

    function forbiddenChars($string, $type = null){
        if($type == "name" || $type == null){
            return preg_match("/[^0-9a-zA-Z_\-\s]/", $string);
        }
        elseif($type == "text"){
            return preg_match("/[^0-9a-zA-Z_\/\r\s\-\+\,\!\.]/", $string);
        }
        elseif($type == "number"){
            return preg_match("/[^0-9\,\.]/", $string);
        }
        elseif($type == "password"){
            return preg_match("/[^0-9a-zA-Z_]/", $string);
        }
    }

    function randomTextGen($no_of_chars){
        $rr = '';
        for($x = 0; strlen($rr) < $no_of_chars; $x++){
            $re = mt_rand(48, 90);
            if($re < 58 || $re > 64){
                $re = dechex($re);
                $re = pack("H*", $re);
                $rr .= $re;
            }
        }
        // $rr = strtolower($rr);
        return $rr;
    }

    function jobIDGenerator(){
        global $connect;

        $id = "jb-" . strtolower(randomTextGen(15));
        $query = $connect -> query("SELECT * FROM jobs WHERE id = '$id'");

        if($query -> num_rows > 0){
            jobIDGenerator();
        }
        else{
            return $id;
        }
    }
    function employerIDGenerator(){
        global $connect;

        $id = "emp-" . strtolower(randomTextGen(16));
        $query = $connect -> query("SELECT * FROM employer WHERE id = '$id'");

        if($query -> num_rows > 0){
            employerIDGenerator();
        }
        else{
            return $id;
        }
    }

?>
