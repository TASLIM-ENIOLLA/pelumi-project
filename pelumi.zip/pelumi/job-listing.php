<?php

     include "php/init.php";
     include "php/processes/components/jobs.php";


     $more_html = '
          <section>
               <div class="container">
                    <div class="text-center">
                         <h1>Jobs</h1>

                         <br>

                         <p class="lead">There are jobs for everyone: from graduates, to undergraduates and even high school students</p>
                    </div>
               </div>
          </section>
          <section class="section-background pt-5">
               <div class="container-fluid">

                    <div class="flex-h flex-wrap">
                         <div class="col-lg-3 col-xs-12">
                              <div class="form">
                                   <form action="#">
                                        <h4>Type</h4>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Contract (54)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Full time (435)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Internship (512)
                                             </label>
                                        </div>

                                        <br>

                                        <h4>Category</h4>

                                        <!-- <div>
                                             <select class="bg-clear p-3 outline-0" style="padding: 10px; display: block; width: 100%; border-radius: 3px;">
                                                  <option>Accounting / Finance / Insurance Jobs (5)</option>
                                                  <option>Accounting / Finance / Insurance Jobs (5)</option>
                                                  <option>Accounting / Finance / Insurance Jobs (5)</option>
                                                  <option>Accounting / Finance / Insurance Jobs (5)</option>
                                                  <option>Accounting / Finance / Insurance Jobs (5)</option>
                                                  <option>Accounting / Finance / Insurance Jobs (5)</option>
                                             </select>
                                        </div> -->
                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Accounting / Finance / Insurance Jobs (5)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Accounting / Finance / Insurance Jobs (5)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Accounting / Finance / Insurance Jobs (5)
                                             </label>
                                        </div>

                                        <br>

                                        <h4>Career levels</h4>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Newbie (54)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Professional (5689)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Expert (54354)
                                             </label>
                                        </div>

                                        <br>

                                        <h4>Education levels</h4>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Graduate (67364)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  Undergarduate (456)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  High schoolers (465)
                                             </label>
                                        </div>

                                        <br>


                                        <h4>Years of experience</h4>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  < 1 year(34)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  3 to 5 years (587)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  5 to 10 years(6589)
                                             </label>
                                        </div>

                                        <div>
                                             <label class="one-line">
                                                  <input type="checkbox">

                                                  11 years and above(4589)
                                             </label>
                                        </div>
                                   </form>
                              </div>
                         </div>

                         <div class="col-lg-9 col-xs-12 mt-5 pt-5">
                              <div class="flex-h flex-wrap">
                                   <!-- <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="courses-thumb courses-thumb-secondary">
                                             <div class="courses-top">
                                                  <div class="courses-image">
                                                       <img src="images/product-1-720x480.jpg" class="img-responsive" alt="">
                                                  </div>
                                                  <div class="courses-date">
                                                       <span title="Posted on"><i class="fa fa-calendar"></i> 15-06-2020</span>
                                                       <span title="Location"><i class="fa fa-map-marker"></i> London</span>
                                                       <span title="Type"><i class="fa fa-file"></i> Contract</span>
                                                  </div>
                                             </div>

                                             <div class="courses-detail">
                                                  <h3><a href="job-details.html">Lorem ipsum dolor sit amet</a></h3>

                                                  <p class="lead"><strong>$60 000</strong></p>

                                                  <p>Medical / Health Jobs for <strong>BMI Kings Park Hospital</strong></p>
                                             </div>

                                             <div class="courses-info">
                                                  <a href="job-details.html" class="section-btn btn btn-primary btn-block">View Details</a>
                                             </div>
                                        </div>
                                   </div>

                                   <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="courses-thumb courses-thumb-secondary">
                                             <div class="courses-top">
                                                  <div class="courses-image">
                                                       <img src="images/product-2-720x480.jpg" class="img-responsive" alt="">
                                                  </div>
                                                  <div class="courses-date">
                                                       <span title="Posted on"><i class="fa fa-calendar"></i> 15-06-2020</span>
                                                       <span title="Location"><i class="fa fa-map-marker"></i> London</span>
                                                       <span title="Type"><i class="fa fa-file"></i> Contract</span>
                                                  </div>
                                             </div>

                                             <div class="courses-detail">
                                                  <h3><a href="job-details.html">Lorem ipsum dolor sit amet</a></h3>

                                                  <p class="lead"><strong>$60 000</strong></p>

                                                  <p>Medical / Health Jobs for <strong>BMI Kings Park Hospital</strong></p>
                                             </div>

                                             <div class="courses-info">
                                                  <a href="job-details.html" class="section-btn btn btn-primary btn-block">View Details</a>
                                             </div>
                                        </div>
                                   </div>

                                   <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="courses-thumb courses-thumb-secondary">
                                             <div class="courses-top">
                                                  <div class="courses-image">
                                                       <img src="images/product-3-720x480.jpg" class="img-responsive" alt="">
                                                  </div>
                                                  <div class="courses-date">
                                                       <span title="Posted on"><i class="fa fa-calendar"></i> 15-06-2020</span>
                                                       <span title="Location"><i class="fa fa-map-marker"></i> London</span>
                                                       <span title="Type"><i class="fa fa-file"></i> Contract</span>
                                                  </div>
                                             </div>

                                             <div class="courses-detail">
                                                  <h3><a href="job-details.html">Lorem ipsum dolor sit amet</a></h3>

                                                  <p class="lead"><strong>$60 000</strong></p>

                                                  <p>Medical / Health Jobs for <strong>BMI Kings Park Hospital</strong></p>
                                             </div>

                                             <div class="courses-info">
                                                  <a href="job-details.html" class="section-btn btn btn-primary btn-block">View Details</a>
                                             </div>
                                        </div>
                                   </div>

                                   <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="courses-thumb courses-thumb-secondary">
                                             <div class="courses-top">
                                                  <div class="courses-image">
                                                       <img src="images/product-4-720x480.jpg" class="img-responsive" alt="">
                                                  </div>
                                                  <div class="courses-date">
                                                       <span title="Posted on"><i class="fa fa-calendar"></i> 15-06-2020</span>
                                                       <span title="Location"><i class="fa fa-map-marker"></i> London</span>
                                                       <span title="Type"><i class="fa fa-file"></i> Contract</span>
                                                  </div>
                                             </div>

                                             <div class="courses-detail">
                                                  <h3><a href="job-details.html">Lorem ipsum dolor sit amet</a></h3>

                                                  <p class="lead"><strong>$60 000</strong></p>

                                                  <p>Medical / Health Jobs for <strong>BMI Kings Park Hospital</strong></p>
                                             </div>

                                             <div class="courses-info">
                                                  <a href="job-details.html" class="section-btn btn btn-primary btn-block">View Details</a>
                                             </div>
                                        </div>
                                   </div>

                                   <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="courses-thumb courses-thumb-secondary">
                                             <div class="courses-top">
                                                  <div class="courses-image">
                                                       <img src="images/product-4-720x480.jpg" class="img-responsive" alt="">
                                                  </div>
                                                  <div class="courses-date">
                                                       <span title="Posted on"><i class="fa fa-calendar"></i> 15-06-2020</span>
                                                       <span title="Location"><i class="fa fa-map-marker"></i> London</span>
                                                       <span title="Type"><i class="fa fa-file"></i> Contract</span>
                                                  </div>
                                             </div>

                                             <div class="courses-detail">
                                                  <h3><a href="job-details.html">Lorem ipsum dolor sit amet</a></h3>

                                                  <p class="lead"><strong>$60 000</strong></p>

                                                  <p>Medical / Health Jobs for <strong>BMI Kings Park Hospital</strong></p>
                                             </div>

                                             <div class="courses-info">
                                                  <a href="job-details.html" class="section-btn btn btn-primary btn-block">View Details</a>
                                             </div>
                                        </div>
                                   </div>

                                   <div class="col-xs-12 col-sm-6 col-md-4">
                                        <div class="courses-thumb courses-thumb-secondary">
                                             <div class="courses-top">
                                                  <div class="courses-image">
                                                       <img src="images/product-6-720x480.jpg" class="img-responsive" alt="">
                                                  </div>
                                                  <div class="courses-date">
                                                       <span title="Posted on"><i class="fa fa-calendar"></i> 15-06-2020</span>
                                                       <span title="Location"><i class="fa fa-map-marker"></i> London</span>
                                                       <span title="Type"><i class="fa fa-file"></i> Contract</span>
                                                  </div>
                                             </div>

                                             <div class="courses-detail">
                                                  <h3><a href="job-details.html">Lorem ipsum dolor sit amet</a></h3>

                                                  <p class="lead"><strong>$60 000</strong></p>

                                                  <p>Medical / Health Jobs for <strong>BMI Kings Park Hospital</strong></p>
                                             </div>

                                             <div class="courses-info">
                                                  <a href="job-details.html" class="section-btn btn btn-primary btn-block">View Details</a>
                                             </div>
                                        </div>
                                   </div> -->
                                   ' . $Jobs -> renderJobsForHomePage() . '
                              </div>
                         </div>
                    </div>
               </div>
          </section>
     ';

     include "template/template.php";

?>