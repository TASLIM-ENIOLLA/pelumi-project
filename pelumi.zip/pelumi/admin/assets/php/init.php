<?php

    include "connect/connect.php";
    include "functions/functions.php";
    include "config/config.php";

?>
