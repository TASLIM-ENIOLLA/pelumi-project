<?php

    $connect = new mysqli(
        "localhost",
        "root",
        "",
        "pelumi_project"
    );

    if($connect -> connect_error){
        die("Connection failed: " . $connect -> connect_error);
    }

    session_start();

?>
