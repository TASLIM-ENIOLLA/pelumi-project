<?php
    define(
        "APP_NAME",
        "Product Expiration Alerter"
    );
?>
