<?php

    if(isset($_POST["logout"])){
        setcookie(
            "MP-HIRES",
            null,
            (time() - (365 * 3600)),
            "/"
        );
        
        header("Location: ../../index.php");
    }
    elseif(isset($_POST["cancel"])){
        header("Location: index.php");
    }

?>
