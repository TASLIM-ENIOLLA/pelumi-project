<?php

    class LoadUserData{
        public function __construct(){
            global $connect;

            $which  = json_decode($_COOKIE["MP-HIRES"]) -> which;
            $emp_id = json_decode($_COOKIE["MP-HIRES"]) -> id;

            $query = $connect -> query(
                "SELECT * FROM $which WHERE id = '$emp_id'"
            );

            if($query == TRUE){
                define(
                    "USER",
                    $query -> fetch_assoc()
                );
                $this -> which = $which;
            }
        }
        public function validate_profile_img($img_src){
            if(
                file_exists("../assets/" . $img_src)
                && !is_dir("../assets/" . $img_src)
            ){
                return "../assets/" . $img_src;
            }
            else{
                return "../assets/img/user_default.png";
            }
        }
    }

    $LoadUserData = new LoadUserData();

?>
