<?php
    include '../../init.php';

    class UpdateAdminData{
        public function __construct(){
            global $Generic;

            if(isset($_POST) && count($_POST) > 0){
                $which = json_decode($_COOKIE["MP-HIRES"]) -> which;
                $this -> which = $which;
                if($which == "employee"){
                    $f_name = $Generic -> filterInput($_POST["f_name"]);
                    $l_name = $Generic -> filterInput($_POST["l_name"]);
                }
                else{
                    $company_name = $Generic -> filterInput($_POST["company_name"]);
                    $location = $Generic -> filterInput($_POST["location"]);
                }
                $phone_number = $Generic -> filterInput($_POST["phone_number"]);
                $email_address = $Generic -> filterInput($_POST["email_address"]);
                $current_password = $Generic -> filterInput($_POST["current_password"]);
                $password = $Generic -> filterInput($_POST["password"]);
                $c_password = $Generic -> filterInput($_POST["c_password"]);

                $profile_img_file = ((!empty($_FILES)) ? $_FILES["profile_img"] : null);

                $this -> user = array(
                    // "f_name" =>  $f_name,
                    // "l_name" =>  $l_name,
                    "phone_number" =>  $phone_number,
                    "email_address" =>  $email_address,
                    "current_password" =>  $current_password,
                    "password" =>  $password,
                    "c_password" =>  $c_password,
                    "profile_img_file" =>  $profile_img_file
                );
                if($which == "employee"){
                    $this -> user["f_name"] = $f_name;
                    $this -> user["l_name"] = $l_name;
                }
                else{
                    $this -> user["company_name"] = $company_name;
                    $this -> user["location"] = $location;
                }

                $this -> validate_user_data();
            }
        }
        public function validate_user_data(){
            $which = $this -> which;
            if(isset($_POST) && count($_POST) > 0){
                global $connect;
                global $Generic;
                $user = $this -> user;
                $user_id = json_decode($_COOKIE["MP-HIRES"]) -> id;

                if(isset($user["profile_img_file"])){
                    $ext_arr = ["jpeg", "jpg", "png", "gif"];
                    $rrr = explode(".", $user["profile_img_file"]["name"]);
                    $ext = strtolower(end($rrr));
                    $user_img_folder = "img/user/" . $user_id . "/";
                    $new_location = $user_img_folder . strtolower($Generic -> randomTextGen(10)) . "." . $ext;

                    if(!file_exists("../../../" . $user_img_folder)){
                        mkdir("../../../" . $user_img_folder, 0777, true);
                    }
                }

                if($which == "employer" && (strlen($user["company_name"]) > 100 || strlen($user["company_name"]) < 1)){
                    $this -> response(
                        "error",
                        "Company name is too long or short (Max. 50 characters)."
                    );
                }
                elseif($which == "employer" && ($Generic -> forbiddenChars($user["company_name"], "name"))){
                    $this -> response(
                        "error",
                        "Company name contains unwanted characters."
                    );
                }

                elseif($which == "employer" && (strlen($user["location"]) < 1)){
                    $this -> response(
                        "error",
                        "Location cannot be empty. Type in your company location."
                    );
                }
                elseif($which == "employer" && ($Generic -> forbiddenChars($user["location"], "text"))){
                    $this -> response(
                        "error",
                        "Location contains unwanted characters."
                    );
                }

                elseif($which == "employee" && (strlen($user["f_name"]) > 50 || strlen($user["f_name"]) < 1)){
                    $this -> response(
                        "error",
                        "First name is too long or short."
                    );
                }
                elseif($which == "employee" && ($Generic -> forbiddenChars($user["f_name"], "name"))){
                    $this -> response(
                        "error",
                        "First name contains unwanted characters (Max. 50 characters)."
                    );
                }

                elseif($which == "employee" && (strlen($user["l_name"]) > 50 || strlen($user["l_name"]) < 1)){
                    $this -> response(
                        "error",
                        "Last name is too long or short."
                    );
                }
                elseif($which == "employee" && ($Generic -> forbiddenChars($user["l_name"], "name"))){
                    $this -> response(
                        "error",
                        "Last name contains unwanted characters (Max. 50 characters)."
                    );
                }

                elseif(strlen($user["phone_number"]) > 20 || strlen($user["phone_number"]) < 1){
                    $this -> response(
                        "error",
                        "Mobile number is too long or short (Max. 20 characters)."
                    );
                }

                elseif($Generic -> forbiddenChars($user["phone_number"], "text")){
                    $this -> response(
                        "error",
                        "Mobile number contains unwanted characters."
                    );
                }

                elseif(strlen($user["email_address"]) > 100 || strlen($user["email_address"]) < 1){
                    $this -> response(
                        "error",
                        "Email address is too long or short."
                    );
                }
                elseif(filter_var(filter_var($user["email_address"], FILTER_SANITIZE_EMAIL), FILTER_VALIDATE_EMAIL) == false){
                    $this -> response(
                        "error",
                        "Email address contains unwanted characters."
                    );
                }

                elseif(strlen($user["password"]) < 8 && $user["password"] != ""){
                    $this -> response(
                        "error",
                        "New password is too short."
                    );
                }

                elseif(strlen($user["password"]) > 100){
                    $this -> response(
                        "error",
                        "New password is too long."
                    );
                }

                elseif($Generic -> forbiddenChars($user["password"], "password") && $user["password"] != ""){
                    $this -> response(
                        "error",
                        "New password contains unwanted characters."
                    );
                }

                elseif($user["password"] != "" && ($user["password"] !== $user["c_password"])){
                    $this -> response(
                        "error",
                        "New passwords do not match."
                    );
                }

                elseif($user["profile_img_file"] != null && !is_file($user["profile_img_file"]["tmp_name"])){
                    $this -> response(
                        "error",
                        "Profile image is not a regular file."
                    );
                }

                elseif($user["profile_img_file"] != null && !array_search(end($rrr), $ext_arr)){
                    $this -> response(
                        "error",
                        "Profile image format is not supported."
                    );

                    $files_in_directory = scandir("../../../" . $user_img_folder);
                    foreach ($files_in_directory as $key => $value) {
                        if(is_file("../../../" . $user_img_folder . $value)){
                            unlink("../../../" . $user_img_folder . $value);
                        }
                    }
                }

                // elseif($product_img["size"] > 1000000){
                    // 1MB?
                    // $response["type"] = "error";
                    // $response["message"] = "Product image size is too large.";
                // }



                elseif($user["profile_img_file"] != null && !move_uploaded_file($user["profile_img_file"]["tmp_name"], "../../../" . $new_location)){
                    $this -> response(
                        "error",
                        "Product image upload failed."
                    );
                }

                else{
                    if($which == "employee"){
                        $f_name = $user["f_name"];
                        $l_name = $user["l_name"];
                    }
                    else{
                        $company_name = $user["company_name"];
                        $location = $user["location"];
                    }
                    $phone_number = $user["phone_number"];
                    $email_address = $user["email_address"];
                    $current_password = md5($user["current_password"]);
                    $password = $user["password"];

                    $query = $connect -> query(
                        "SELECT * FROM $which WHERE id = '$user_id' AND password = '$current_password'"
                    );

                    if($query -> num_rows > 0){
                        #f_name = '$f_name', l_name = '$l_name',
                        $sql = "UPDATE $which SET phone_number = '$phone_number', email_address = '$email_address'";

                        if(strlen($password) > 7){
                            $password = md5($password);
                            $sql .= ", password = '$password'";
                        }
                        if(isset($new_location)){
                            $sql .= ", profile_img = '$new_location'";
                        }

                        if($which == "employee"){
                            $sql .= ", f_name = '$f_name'";
                            $sql .= ", l_name = '$l_name'";
                        }
                        elseif($which == "employer"){
                            $sql .= ", company_name = '$company_name'";
                            $sql .= ", location = '$location'";
                        }

                        $sql .= " WHERE id = '$user_id'";

                        $query = $connect -> query($sql);

                        if($query === TRUE){
                            $this -> response(
                                "success",
                                "User data updated successfully."
                            );

                            $_POST = null;
                            $_FILES = null;
                        }
                        else{
                            var_dump($connect);
                            $this -> response(
                                "error",
                                "Passwords do not match."
                            );
                        }
                    }
                    else{
                        $this -> response(
                            "error",
                            "Current passwords seems incorrect. Try again."
                        );
                    }
                }
            }
        }
        private function response($type, $message){
            echo json_encode(
                array(
                    "type" => $type,
                    "message" => $message
                )
            );
        }
    }

    $UpdateAdminData = new UpdateAdminData();
?>
