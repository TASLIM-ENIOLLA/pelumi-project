<?php

    include "../../init.php";

    class DeleteCategory{
        public function __construct(){
            global $connect;
            global $Generic;

            if(!empty($_GET)){
                $category_list = json_decode($_GET["category_list"]);

                $list = "";

                foreach ($category_list as $category_id => $key){
                    $list .= "'" . $category_list[$category_id] . "'";

                    if($category_id < count($category_list) - 1){
                        $list .= ", ";
                    }
                }

                $query = $connect -> query("DELETE FROM category WHERE id IN ($list)");

                if($query){
                    echo json_encode(array(
                        "type" => "success",
                        "message" => "Category deleted successfully!"
                    ));
                }
                else{
                    echo json_encode(array(
                        "type" => "error",
                        "message" => "Something went wrong! Try again."
                    ));
                }
            }
        }
    }

    $DeleteCategory = new DeleteCategory();

?>
