<?php
    class LoadJobs{
        public $row_length = 0;
        public function __construct(){
            global $connect;

            $query = $connect -> query(
                "SELECT * FROM jobs ORDER BY `jobs`.`timestamp` DESC"
            );

            $this -> row_length = $query -> num_rows;
            $this -> query = $query;
        }
        public function render(){

            if($this -> row_length > 0){
                $rows = 0;
                $res = '
                    <div>
                        <div class = "pb-2 bold">Retrieved <span id = "record-returned">' . $this -> row_length . '</span> out of <span id = "record-total">' . $this -> row_length . '</span> record(s)</div>
                        <div class = "border rounded-lg bg-white shadow flex-h j-c-c a-i-c mb-3">
                            <input type = "search" id = "search_query" class = "flex-1 border-0 py-2 px-3 outline-0" placeholder = "Type keyword..."/>
                            <div class = "p-2 my-1 border-left">
                                <span>Search by: </span>
                                <select id = "search_category" class = "border p-2 text-secondary outline-0 rounded bold text-capitalize">
                                    <option value = "name" selected>name</option>
                                    <option value = "category">job category</option>
                                    <option value = "payment">payment</option>
                                    <option value = "type">job type</option>
                                    <option value = "location">location</option>
                                </select>
                            </div>
                            <span title = "Make search" id = "search" class = "fa fa-search pl-3 pr-4 h-100 theme-color flicker cursor-pointer" style = "font-size: 1.5rem;"></span>
                        </div>
                    </div>
                    <div id = "product-list" class = "flex-1 overflow-y-auto">
                ';
                while($row = $this -> query -> fetch_assoc()){
                    $row["image"] = (($row["image"] == null) ? "../assets/img/default.png" : ((file_exists("../assets/" . $row["image"])) ? "../assets/" . $row["image"] : "../assets/img/default.png"));
                    $res .= '
                        <div
                            class="border-bottom animated fadeIn p-3 mb-3 flex-h cursor-pointer flicker transit"
                            style="animation-delay: 0.1s;"
                            data-id = "' . $row["id"] . '" data-name = "' . $row["title"] . '"
                            data-category = "' . $row["job_category"] . '"
                            data-type = "' . $row["job_type"] . '"
                            data-location = "' . $row["location"] . '"
                            data-payment = "' . $row["payment"] . '"
                            >
                            <div class = "pr-3">
                                <input class = "border" type = "checkbox" name="' . $rows . '" id="' . $rows . '" value = "' . $row["id"] . '" />
                            </div>
                            <div class = "flex-1 flex-h">
                                <a href = "view_job.php?job_id=' . $row["id"] . '">
                                    <div class="border shadow rounded" style="width: 60px; height: 60px; borderradius: 50%; background: url(' . $row["image"] . ') center center / cover, lightgrey;"></div>
                                </a>
                                <label for = "' . $rows . '" class="flex-1 pl-3">
                                    <div class="w-100 flex-h">
                                        <div class="flex-1 flex-h">
                                            <span class="text-capitalize text-dark flex-1 single-line expandables">
                                                <span class="bold">' . $row["title"] . '</span> | <span>' . $row["job_category"] . '</span>
                                            </span>
                                        </div>
                                        <div>
                                            <span class="bold text-uppercase theme-color">₦' . number_format($row["payment"]) . '</span>
                                        </div>
                                    </div>
                                    <div class="w-100 flex-h">
                                        <span class="text-capitalize bold text-success flex-1 single-line expandables">Created: ' . date("M Y", strtotime($row["timestamp"])) . '</span>
                                    </div>
                                    <div class="w-100 flex-h">
                                        <span class="text-capitalize text-secondary flex-1 single-line expandables">Payment interval: ' . $row["payment_interval"] . '</span>
                                    </div>
                                    <div class="w-100 flex-h">
                                        <span class="text-capitalize text-secondary flex-1 single-line expandables">Location: ' . $row["location"] . '</span>
                                    </div>
                                    <div class="w-100 flex-h">
                                        <span class="text-capitalize text-secondary flex-1 single-line expandables">Job type: ' . $row["job_type"] . '</span>
                                    </div>
                                    <div class="w-100 flex-h">
                                        <span class="text-capitalize text-secondary flex-1 single-line expandables">Payment: ₦' . number_format($row["payment"]) . '</span>
                                    </div>
                                </label>
                            </div>
                        </div>
                    ';

                    $rows++;
                }
                $res .= "
                    </div>
                    <script>
                        var product_list_JSON = document.querySelectorAll('#product-list > div');
                    </script>
                ";
                return $res;
            }
            else{
                return '
                    <div class = "w-100">
                        <div class = "p-5 my-5 text-secondary mx-auto col-12 bg-light shadow-sm rounded text-c bold">
                            Job list is empty! Click <a href="add_product.php">here</a> to add new jobs.
                        </div>
                    </div>
                ';
            }
        }
    }

    $LoadJobs = new LoadJobs();
?>
