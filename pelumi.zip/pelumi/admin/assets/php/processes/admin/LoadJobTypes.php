<?php

    class LoadJobTypes{
        public function __construct(){
            global $connect;

            $query = $connect -> query(
                "SELECT * FROM type ORDER BY timestamp DESC"
            );

            $this -> query = $query;
        }

        public function markup($value){
            if($this -> query -> num_rows > 0){
                $markup = '
                    <option class = "p-3 text-capitalize" value = "null">-- No category selected --</option>
                ';

                while($row = $this -> query -> fetch_assoc()){
                    $markup .= '
                        <option class = "p-3 text-capitalize" ' . (($row["name"] == $value) ? "selected" : "") . ' value = "' . $row["name"] . '">' . $row["name"] . '</option>
                    ';
                }

                return $markup;
            }
        }
        // public function table_data(){
        //     if($this -> query -> num_rows > 0){
        //         $markup = '';
        //         $counter = 1;

        //         while($row = $this -> query -> fetch_assoc()){
        //             $markup .= '
        //                 <tr class = "flex-h">
        //                     <td class = "bold text-c" style = "width: 40px;">
        //                         <input type = "checkbox" data-checked = "false" class = "category-checkbox" value = "' . $row["id"] . '"/>
        //                     </td>
        //                     <td class = "bold text-c" style = "width: 60px;">' . $counter . '</td>
        //                     <td class = "flex-1">' . $row["name"] . '</td>
        //                     <td class = "flex-1">' . (($row["description"] == null) ? "-- No description available --" : $row["description"]) . '</td>
        //                     <td class = "flex-1">' . date("M d, Y", strtotime($row["timestamp"])) . '</td>
        //                 </tr>
        //             ';

        //             $counter++;
        //         }

        //         return $markup;
        //     }
        //     else{
        //         return '
        //             <tr>
        //                 <td colspan = "4" class = "bold text-c p-5 text-secondary">No exiting category</td>
        //             </tr>
        //         ';
        //     }
        // }
    }

    $LoadJobTypes = new LoadJobTypes();

?>
