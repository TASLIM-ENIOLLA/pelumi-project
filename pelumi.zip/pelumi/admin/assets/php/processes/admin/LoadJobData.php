<?php

    class LoadJobData{
        function __construct(){
            global $connect;

            if(isset($_GET["job_id"])){
                $this -> job_id = $job_id = $_GET["job_id"];

                $query = $connect -> query(
                    "SELECT * FROM jobs WHERE id = '$job_id'"
                );

                if($query && $query -> num_rows > 0){
                    $this -> job_data = $query -> fetch_assoc();
                    $this -> job_data["image"] = (($this -> job_data["image"] == null) ? "img/default.png" : $this -> job_data["image"]);
                    $this -> display_job_data();
                }
                else{
                    $this -> job_data = null;
                    $this -> job_not_found();
                }
            }
        }

        private function format_due_date($todays_date = null, $expr_date = null){
            $todays_date = (($todays_date) ? $todays_date : date("Y-m-d h:i:s"));
            $expr_date = (($expr_date) ? $expr_date : $this -> job_data["expiration_date"]);

            $diff = date_diff(date_create($todays_date), date_create($expr_date));

            $y = $diff -> y;
            $m = $diff -> m;
            $d = $diff -> d;
            $res = "";

            if($y > 0){
                $res .= (($y == 1) ? $y . " year" : $y . " years");

                if($m > 0){
                    $res .= ", ";
                }
            }

            if($m > 0){
                $res .= (($m == 1) ? $m . " month" : $m . " months");


                if($d > 0){
                    $res .= ", ";
                }
            }

            if($d > 0){
                $res .= (($d == 1) ? $d . " day" : $d . " days");
            }

            return $res;
        }

        public function display_job_data(){
            if($this -> job_data != null){
                return '
                    <div class = "flex-h flex-1 overflow-y-auto flex-wrap pt-3">
                        <div class = "col-12">
                            <div class = "bg-light p-3 rounded-lg mb-4 border flex-v j-c-c a-i-c">
                                <img id = "profile_img_preview" src = "' . ((file_exists("../assets/" . $this -> job_data["image"])) ? "../assets/" . $this -> job_data["image"] : "../assets/img/corrupt_img.png") . '" class="d-block border shadow-sm p-0 rounded-lg mx-auto col-10" style = "max-width: 280px;"/>
                            </div>
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Job Name</span>
                            <input readonly value = "' . $this -> job_data["title"] . '" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Payment</span>
                            <input readonly value = "₦' . number_format($this -> job_data["payment"]) . '" placeholder = "+[Country Code] [Phone Number]" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Payment Interval</span>
                            <input readonly value = "' . $this -> job_data["payment_interval"] . '" type = "text" class = "p-3 border text-capitalize my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Job Category</span>
                            <input readonly value = "' . $this -> job_data["job_category"] . '" type = "text" class = "p-3 text-capitalize border my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Location</span>
                            <input readonly value = "' . $this -> job_data["location"] . '" type = "text" class = "p-3 border text-capitalize my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Job Type</span>
                            <input readonly value = "' . $this -> job_data["job_type"] . '" type = "text" class = "p-3 border text-capitalize my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Job Description</span>
                            <textarea readonly class = "p-3 border my-2 resize-0 rounded d-block w-100 outline-0">' . $this -> job_data["job_description"] . '</textarea>
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Job Responsibilities</span>
                            <textarea readonly class = "p-3 border my-2 resize-0 rounded d-block w-100 outline-0">' . $this -> job_data["job_responsibilities"] . '</textarea>
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Job Qualification</span>
                            <input readonly value = "' . $this -> job_data["job_qualifications"] . '" type = "text" class = "p-3 text-capitalize border my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 pt-4">
                            <a
                                href = "add_job.php?action=edit_jobs&job_id=' . $this -> job_data["id"] . '"
                                class = "theme-border theme-bg text-capitalize bold text-white text-c d-block w-100 rounded-lg p-3">
                                edit job info
                            </a>
                        </div>
                        <div class = "col-12 pt-4">
                            <a href = "javascript:void(0);" onclick = "delete_job(this)" data-job-id = "' . $this -> job_data["id"] . '" class = "bg-danger text-capitalize bold text-white text-c d-block w-100 rounded-lg p-3">
                                delete job
                            </a>
                        </div>
                    </div>
                ';
            }
            else{
                return '
                    <div class = "p-5 bg-light shadow-sm text-c rounded-lg text-muted bold">
                        This job was not found on the database!
                    </div>
                ';
            }
        }

        public function job_not_found(){
            return '
                <div class = "bg-light p-5 text-secondary bold text-c shadow-sm">

                </div>
            ';
        }
    }

    $LoadJobData = new LoadJobData();

?>
