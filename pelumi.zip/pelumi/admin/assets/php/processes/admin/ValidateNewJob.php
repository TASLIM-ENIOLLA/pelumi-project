<?php

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        include '../../init.php';
    }
    // var_dump($_SERVER);

    class ValidateNewJob{
        public function __construct(){
            if(isset($_POST) && !empty($_POST)){
                global $connect;
                global $Generic;

                $job_id = $Generic -> job_id_gen();
                $title = $Generic -> filterInput($_POST["title"]);
                $payment = $Generic -> filterInput($_POST["payment"]);
                $job_category = $Generic -> filterInput($_POST["job_category"]);
                $payment_interval = $Generic -> filterInput($_POST["payment_interval"]);
                $job_description = $Generic -> filterInput2($_POST["job_description"]);
                $job_responsibilities = $Generic -> filterInput2($_POST["job_responsibilities"]);
                $location = $Generic -> filterInput2($_POST["location"]);
                $job_type = $Generic -> filterInput($_POST["job_type"]);
                $job_qualifications = $Generic -> filterInput($_POST["job_qualifications"]);
                $job_img = ((!empty($_FILES["job_img"]["name"])) ? $_FILES["job_img"] : NULL);

                $this -> new_product = array(
                    "job_id" => $job_id,
                    "title" => $title,
                    "payment" => $payment,
                    "job_category" => $job_category,
                    "payment_interval" => $payment_interval,
                    "job_description" => $job_description,
                    "job_responsibilities" => $job_responsibilities,
                    "location" => $location,
                    "job_type" => $job_type,
                    "job_qualifications" => $job_qualifications,
                    "job_img" => $job_img
                );
                // var_dump($this -> new_product);
                $this -> validate_form_data();
                $_SESSION["form_data"] = $this -> new_product;
            }
        }
        public function validate_form_data(){
            global $Generic;
            global $connect;

            if(isset($_POST["add_product"])){
                $job_id = $this -> new_product["job_id"];
                $title = $this -> new_product["title"];
                $payment = $this -> new_product["payment"];
                $job_category = $this -> new_product["job_category"];
                $payment_interval = $this -> new_product["payment_interval"];
                $job_description = $this -> new_product["job_description"];
                $job_responsibilities = $this -> new_product["job_responsibilities"];
                $location = $this -> new_product["location"];
                $job_type = $this -> new_product["job_type"];
                $job_qualifications = $this -> new_product["job_qualifications"];
                $job_img = $this -> new_product["job_img"];

                if(strlen($title) > 60 || strlen($title) < 1){
                    $response["type"] = "error";
                    $response["message"] = "Job name too short or long (Max. 60 characters).";
                }
                elseif($Generic -> forbiddenChars($title, "name")){
                    $response["type"] = "error";
                    $response["message"] = "Job name contains unwanted characters.";
                }

                elseif(strlen($payment) < 1){
                    $response["type"] = "error";
                    $response["message"] = "Payment amount unacceptable.";
                }

                elseif(strlen($location) < 1){
                    $response["type"] = "error";
                    $response["message"] = "Location cannot be empty.";
                }
                elseif($Generic -> forbiddenChars($payment, "number")){
                    $response["type"] = "error";
                    $response["message"] = "Payment amount contains unwanted characters.";
                }

                elseif($Generic -> forbiddenChars($payment_interval, "text")){
                    $response["type"] = "error";
                    $response["message"] = "Payment interval unacceptable.";
                }

                elseif($Generic -> forbiddenChars($job_type, "text")){
                    $response["type"] = "error";
                    $response["message"] = "Job type unacceptable.";
                }

                elseif($Generic -> forbiddenChars($job_qualifications, "text")){
                    $response["type"] = "error";
                    $response["message"] = "Job type unacceptable.";
                }

                else{
                    $job_description = ((strlen($job_description) > 0) ? $job_description : NULL);
                    $job_responsibilities = ((strlen($job_responsibilities) > 0) ? $job_responsibilities : NULL);

                    if(true){

                        if($job_img["tmp_name"] == ""){

                            // $admin_id = json_decode($_COOKIE["PProject"]) -> id;
                            $admin_id = 'taslim';

                            if(isset($_GET["action_type"]) && $_GET["action_type"] == "update"){
                                $product_id = $_GET["product_id"];

                                $query = $connect -> query(
                                "UPDATE `jobs` SET `title` = '$title', `payment` = '$payment', `payment_interval` = '$payment_interval', `job_category` = '$job_category', `location` = '$location', `job_type` = '$job_type', `job_description` = '$job_description', `job_responsibilities` = '$job_responsibilities', `job_qualifications` = '$job_qualifications', `image` = '$job_img' WHERE `id` = '$id'"
                                );

                                if($query === TRUE){
                                    $_POST = NULL;
                                    $response["type"] = "success";
                                    $response["message"] = "Job updated successfully.";
                                }
                                else{
                                    $response["type"] = "error";
                                    $response["message"] = "Could not update product data. Try again!";
                                }
                            }
                            else{
                                $query = $connect -> query(
                                "INSERT INTO jobs (`id`, `title`, `payment`, `payment_interval`, `job_category`, `location`, `job_type`, `job_description`, `job_responsibilities`, `job_qualifications`, `image`) VALUES ('$job_id', '$title', '$payment', '$payment_interval', '$job_category', '$location', '$job_type', '$job_description', '$job_responsibilities', '$job_qualifications', '')"
                                );

                                if($query){
                                    $_POST = NULL;
                                    $response["type"] = "success";
                                    $response["message"] = "New product added successfully.";
                                }
                                else{
                                    $response["type"] = "error";
                                    $response["message"] = "Something went wrong.";
                                }
                            }
                        }
                        else{

                            $ext_arr = ["jpeg", "jpg", "png", "gif"];
                            $ext = strtolower(explode(".", $job_img["name"])[1]);
                            if(!file_exists('../../../img/jobs/')){
                                mkdir('../../../img/jobs/');
                            }
                            $new_location = "img/jobs/" . time() . "." . $ext;

                            if(!is_file($job_img["tmp_name"])){
                                $response["type"] = "error";
                                $response["message"] = "Job image is not a regular file.";
                            }
                            elseif(!array_search(explode(".", strtolower($job_img["name"]))[1], $ext_arr)){
                                $response["type"] = "error";
                                $response["message"] = "Job image format is not supported.";
                            }
                            // elseif($job_img["size"] > 1000000){
                            // 1MB?
                            // $response["type"] = "error";
                            // $response["message"] = "Job image size is too large.";
                            // }
                            elseif(!move_uploaded_file($job_img["tmp_name"], "../../../" . $new_location)){
                                $response["type"] = "error";
                                $response["message"] = "Job image upload failed.";
                            }
                            else{
                                // $admin_id = json_decode($_COOKIE["PEA"]) -> id;
                                $admin_id = 'taslim';

                                if(isset($_GET["action_type"]) && $_GET["action_type"] == "update"){
                                    $query = $connect -> query(
                                    "UPDATE `jobs` SET `admin_id` = '$admin_id', `name` = '$product_name', `category_id` = '$product_category', `description` = '$product_description', `quantity` = '$product_qty', `image` = '$new_location', `buy_price` = '$buy_price', `sell_price` = '$sell_price', `production_date` = '$prod_date', `expiration_date` = '$expr_date' WHERE `id` = '$product_id'"
                                    );

                                    if($query === TRUE){
                                        $_POST = NULL;
                                        $response["type"] = "success";
                                        $response["message"] = "Job updated successfully.";
                                    }
                                    else{
                                        $response["type"] = "error";
                                        $response["message"] = "Could not update product data. Try again!";
                                    }
                                }
                                else{
                                    $query = $connect -> query(
                                    "INSERT INTO jobs (`id`, `title`, `payment`, `payment_interval`, `job_category`, `location`, `job_type`, `job_description`, `job_responsibilities`, `job_qualifications`, `image`) VALUES ('$job_id', '$title', '$payment', '$payment_interval', '$job_category', '$location', '$job_type', '$job_description', '$job_responsibilities', '$job_qualifications', '$new_location')"
                                    );
                                    
                                    if($query){
                                        $_POST = NULL;
                                        $response["type"] = "success";
                                        $response["message"] = "New product added successfully.";
                                    }
                                    else{
                                        $response["type"] = "error";
                                        $response["message"] = "Something went wrong.";
                                    }
                                }
                            }
                        }
                    }
                }

                // $response["type"] = 'success';
                // $response["message"] = 'jvngbkfjbgf';

                $this -> response($response["type"], $response["message"]);
            }
        }

        public function on_success(){
            if(isset($_SESSION["message"])){
                $message = $_SESSION["message"];
                $_SESSION["message"] = NULL;

                return $this -> response("success", $message);
            }
        }

        private function response($type, $message){
            echo json_encode(
                array(
                    "type" => $type,
                    "message" => $message
                )
            );
        }

        public function format_date($date, $format){
            if(date_create($date)){
                return date_format(date_create($date), $format);
            }
            else{
                return "";
            }
        }

        public function is_set($var){
            return ((isset($var)) ? $var : "");
        }

        public function validate_image($img_src){
            if(file_exists($img_src)){
                return $img_src;
            }
            else{
                return "../assets/img/corrupt_img.png";
            }
        }
    }

    $ValidateNewJob = new ValidateNewJob();

?>
