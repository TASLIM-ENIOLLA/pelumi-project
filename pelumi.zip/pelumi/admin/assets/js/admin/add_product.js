class AddProduct{
    constructor(){
        document.querySelectorAll("input, textarea, select").forEach(
            item => {
                item.addEventListener(
                    "input",
                    () => {
                        if(document.querySelector("input[name = 'add_product']").classList.contains("disabled")){
                            document.querySelector("input[name = 'add_product']").classList.remove("disabled");
                        }
                    }
                );
            }
        );
        document.querySelector("input[name = 'add_product']").addEventListener(
            "click",
            (e) => {
                let formData = new FormData();

                e.srcElement.form.onsubmit = (f) => {
                    f.preventDefault();
                }
                // console.log(e.srcElement.form.querySelectorAll("input"))
                e.srcElement.form.querySelectorAll("input, textarea, select").forEach(
                    item => {
                        if(item.type == "file" && item.files.length > 0){
                            console.log(item);
                            formData.append(item.name, item.files[0])
                        }
                        else{
                            formData.append(item.name, item.value)
                        }
                    }
                );

                let get_query = e.srcElement.form.action.split("?")[1] || "";
                get_query = "?" + get_query;

                let xmlHtttp = new XMLHttpRequest();
                xmlHtttp.onreadystatechange = function(){
                    if(xmlHtttp.readyState == 4 && xmlHtttp.status == 200){
                        console.log(xmlHtttp.responseText)
                        try{
                            let responseText = JSON.parse(xmlHtttp.responseText);
                            toast(responseText.message, ((responseText.type == "error") ? "danger" : "primary"));
                            e.srcElement.classList.add("disabled");
                        }
                        catch(e){
                            toast("An error occured", "danger", 5000)
                        }

                    }
                };
                xmlHtttp.open(
                    "POST",
                    "../assets/php/processes/admin/ValidateNewJob.php" + get_query,
                    true
                );
                xmlHtttp.send(formData);
            }
        );

        document.querySelector("input[name = 'job_img']").oninput = (e) => {
            var reader = new FileReader();
            reader.onload = () => {
                var dataURL = reader.result;
                var output = document.querySelector("#preview_img");
                output.src =
                    dataURL;
            }
            reader.readAsDataURL(e.srcElement.files[0]);
        }
    }
}

var addProduct = new AddProduct();
