document.querySelector("#submit-login").addEventListener(
    "click",
    (e) => {
        let user_id = document.querySelector("#login #user_id").value;
        let password = document.querySelector("#login #password").value;
        let login_credentials = {
            "email" : user_id,
            "password" : password
        };
        login_credentials = JSON.stringify(login_credentials);

        let xmlHtttp = new XMLHttpRequest();
        xmlHtttp.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                let responseText = this.responseText;

                if(responseText != "error" && responseText != "failed"){
                    if(responseText == "student"){
                        toast("Login successful. Getting things ready...", "light", 2000).then(
                            e => window.location.replace("../admin/index.php")
                        );
                    }
                }
                else if(responseText == "failed"){
                    toast("Login credentials seem incorrect.");
                }
                else if(responseText == "error"){
                    toast("An error occured, please try again.");
                }
            }
        };
        xmlHtttp.open(
            "POST",
            "../assets/php/processes/login.php",
            true
        );
        xmlHtttp.setRequestHeader(
            "Content-type",
            "application/x-www-form-urlencoded"
        );
        xmlHtttp.send("login_credentials=" + login_credentials);
    }
);

// function toast(message, background = "light", duration = 4000){
//     let body = document.body;
//
//     let a = document.createElement("div");
//     a.className = "py-3 px-4 btn-" + background + " shadow animated text-c fadeIn po-abs cursor-pointer user-select-0";
//     a.style = "max-width: 100%; min-width: 10%; top: 5%; left: 50%; z-index: " + TOAST_Z_INDEX_COUNT + "; transform: translate(-50%, 0); width: auto; border-radius: 30px;";
//     a.innerHTML = message;
//     TOAST_Z_INDEX_COUNT = Number(TOAST_Z_INDEX_COUNT) + 1;
//
//     body.appendChild(a);
//
//     return new Promise(
//         res => {
//             setTimeout(
//                 () => {
//                     return new Promise(
//                         () => {
//                             a.classList.replace("fadeIn", "fadeOut");
//                             a.addEventListener(
//                                 "animationend",
//                                 () => {
//                                     a.remove();
//                                     res("success");
//                                 }
//                             );
//                         }
//                     );
//                 }, duration
//             );
//         }
//     );
// }
