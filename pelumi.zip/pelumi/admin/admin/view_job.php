<?php

    if(!isset($_GET["job_id"])){
        header("Location: index.php");
    }

    include '../assets/php/init.php';
    include '../assets/php/processes/admin/LoadJobData.php';


    $section = '
        <div class="py-4 px-3 h-100 flex-v">
            <div class="p-3 flex-h a-i-c">
                <a href = "all_products.php"><h4 class="bold theme-color text-capitalize">All Products |&nbsp;</h4></a>
                <h4 class="bold text-secondary text-capitalize">' .  $LoadJobData -> job_data["title"] . '</h4>
            </div>
            <div class = "p-3 flex-1 overflow-y-auto">
                ' . $LoadJobData -> display_job_data() . '
            </div>
        </div>

        <script src = "../assets/js/admin/view_job.js"></script>
    ';

    include "template/template.php";

?>
