<?php

    include '../assets/php/init.php';
    include '../assets/php/processes/admin/Loadjobs.php';


    $section = '
        <form method="POST" id = "product_form" action = "" class="py-4 px-3 flex-v h-100">
            <div class="p-3 text-muted flex-h">
                <div class="flex-1 flex-h">
                    <h4 class="bold text-capitalize flex-1 single-line theme-color">All jobs</h4>
                </div>' .
                (($LoadJobs -> row_length > 0) ? '
                    <div class="px-2">
                        <label for = "delete_products" title = "Delete products" class = "p-2 fa fa-trash text-danger cursor-pointer flicker" style="transform: scale(1.5);">
                            <input type = "submit" hidden id = "delete_products"/>
                        </label>
                    </div>
                ' : "") . '
            </div>
            <div class="px-3 m-0 flex-1 flex-v overflow-y-auto">
                ' . $LoadJobs -> render() . '
            </div>
        </form>

        <script src = "../assets/js/admin/all_jobs.js"></script>
    ';

    include "template/template.php";

?>
