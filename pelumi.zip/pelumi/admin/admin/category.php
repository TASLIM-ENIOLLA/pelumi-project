<?php

    include "../assets/php/init.php";
    include "../assets/php/processes/admin/LoadProductsCategories.php";

    $section = '
        <div class="py-4 px-3 h-100 flex-v po-rel">
            <div class="p-3">
                <h4 class="bold theme-color text-capitalize">Product category</h4>
                <div class = "pb-3 text-r flex-h j-c-space-between a-i-c">
                    <div>
                        <span class = "bold">Returned 5 of 5 record(s)</span>
                    </div>
                    <div>
                        <button title = "Add new category" class = "theme-bg ml-3 px-4 py-3 text-white outline-0 flicker rounded shadow text-capitalize bold border-0 overflow-0 add_category">
                            <span class="fa fa-plus-square" style = "transform: scale(1.3);"></span>
                        </button>
                        <button title = "Delete category" class = "delete_category bg-danger ml-3 px-4 py-3 text-white outline-0 flicker rounded shadow text-capitalize bold border-0 overflow-0">
                            <span class="fa fa-trash" style = "transform: scale(1.3);"></span>
                        </button>
                    </div>
                </div>
            </div>
            <div class = "flex-1 overflow-y-auto border rounded m-3">
                <div class = "overflow-x-auto flex-v h-100">
                    <div style = "min-width: 576px;">
                        <table class = "table border table-striped m-0">
                            <thead class = "theme-bg text-white text-capitalize">
                                <tr class = "flex-h">
                                    <th class = "single-line text-c" style = "width: 40px;">
                                        <span class = "fa fa-check-square-o" id = "select_all"></span>
                                    </th>
                                    <th class = "single-line text-c" style = "width: 60px;">S/N</th>
                                    <th class = "single-line flex-1">Job category</th>
                                    <th class = "single-line flex-1">Job description</th>
                                    <th class = "single-line flex-1">date created</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div class = "flex-1 overflow-y-auto" style = "min-width: 576px;">
                        <table class = "table table-striped m-0">
                            <tbody>
                                ' . $LoadProductsCategories -> table_data() . '
                            </tbody>
                        </table>
                    </div>
                    <!-- <table border="1" style = "min-width: 576px;" class = "table border table-striped">
                        <thead class = "theme-bg text-white text-capitalize">
                            <tr>
                                <th class = "single-line text-c">
                                    <span class = "fa fa-check-square-o" id = "select_all"></span>
                                </th>
                                <th class = "single-line text-c">S/N</th>
                                <th class = "single-line">Job category</th>
                                <th class = "single-line">Job description</th>
                                <th class = "single-line">date created</th>
                            </tr>
                        </thead>
                        <tbody>
                            ' . $LoadProductsCategories -> table_data() . '
                        </tbody>
                    </table> -->
                </div>
            </div>
        </div>

        <div id = "add_category_pane" class = "h-100 animated fadeIn d-none w-100 po-abs px-4 top-0 left-0 py-5" style="background: rgba(0, 0, 0, .5);">
            <div class = "bg-white shadow p-3 mx-auto" style = "border-radius: 20px; max-width: 500px;">
                <div class = "text-c py-3 flex-h">
                    <span style = "font-size: 1.3em;" class = "bold theme-color flex-1 single-line text-capitalize">add Jobs</span>
                </div>
                <form action = "" id = "add_category" class = "flex-h flex-wrap py-4">
                    <div class = "col-12 mb-4">
                        <span class = "bold text-capitalize">Job category</span>
                        <input required name = "category_name" type = "text" class = "p-3 mt-2 d-block w-100 border outline-0 rounded bg-clear" />
                    </div>
                    <div class = "col-12 mb-4">
                        <span class = "bold text-capitalize">Job description</span>
                        <textarea name = "category_description" class = "p-3 mt-2 d-block w-100 border outline-0 rounded resize-0 bg-clear"></textarea>
                    </div>
                    <div class = "col-12">
                        <input type = "submit" class = "p-3 mt-4 d-block text-white bold text-capitalize w-100 border outline-0 rounded-lg theme-bg" />
                    </div>
                </form>
            </div>
        </div>

        <script src = "../assets/js/admin/category.js"></script>
    ';

    include "template/template.php";

?>
