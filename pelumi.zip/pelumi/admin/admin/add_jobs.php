<?php

    include '../assets/php/init.php';
    include '../assets/php/processes/admin/LoadJobsCategories.php';
    include '../assets/php/processes/admin/LoadJobTypes.php';
    include '../assets/php/processes/admin/LoadJobQualifications.php';
    include '../assets/php/processes/admin/LoadJobData.php';
    include '../assets/php/processes/admin/ValidateNewJob.php';

    $section = '
        <div class="py-4 px-3 h-100 flex-v">
            <div class="p-3 text-muted">
                <h4 class="bold text-capitalize theme-color">' . ((isset($_GET["action"])) ? "edit job" : "add job") . '</h4>
            </div>
            <form class="py-3 row m-0 flex-1 overflow-y-auto" method = "POST" action = "add_product.php' . ((isset($_GET["action"]) && $_GET["action"] == "edit_product") ? "?action_type=update&product_id=" . $_GET["product_id"] : "") . '" enctype = "multipart/form-data">
                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Title *</span>
                    <input value = "' . ((isset($LoadJobData -> job_data["title"])) ? $LoadJobData -> job_data["title"] : ((isset($_POST["title"])) ? $_POST["title"] : "")) . '" name = "title" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                </div>

                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Payment (₦) *</span>
                    <input min = "1" value = "' . ((isset($LoadJobData -> job_data["payment"])) ? $LoadJobData -> job_data["payment"] : ((isset($_POST["payment"])) ? $_POST["payment"] : "")) . '" name = "payment" type = "number" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                </div>

                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Job category *</span>
                    <select name = "job_category" class = "p-3 text-capitalize border my-2 rounded d-block w-100 outline-0">
                        ' . $LoadJobsCategories -> markup(((isset($LoadJobData -> job_data["job_category"])) ? $LoadJobData -> job_data["job_category"] : ((isset($_POST["job_category"])) ? $_POST["job_category"] : ""))) . '
                    </select>
                </div>

                 <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Payment interval *</span>
                    <select name = "payment_interval" class = "p-3 text-capitalize border my-2 rounded d-block w-100 outline-0">
                        <option class = "p-3 text-capitalize" value = "null">-- No category selected --</option>
                        <option class = "p-3 text-capitalize" value = "weekly">weekly</option>
                        <option class = "p-3 text-capitalize" value = "monthly">monthly</option>
                        <option class = "p-3 text-capitalize" value = "yearly">yearly</option>
                    </select>
                </div>

                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Job description *</span>
                    <textarea name="job_description" rows="3" class = "p-3 border my-2 rounded d-block w-100 outline-0 resize-0">' . ((isset($LoadJobData -> job_data["job_description"])) ? $LoadJobData -> job_data["job_description"] : ((isset($_POST["job_description"])) ? $_POST["job_description"] : "")) . '</textarea>
                </div>

                 <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Job responsibilities *</span>
                    <textarea name = "job_responsibilities" rows="3" class = "p-3 border my-2 rounded d-block w-100 outline-0 resize-0">' . ((isset($LoadJobData -> job_data["job_responsibilities"])) ? $LoadJobData -> job_data["job_responsibilities"] : ((isset($_POST["job_responsibilities"])) ? $_POST["job_responsibilities"] : "")) . '</textarea>
                </div>

                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Location *</span>
                    <input value = "' . ((isset($LoadJobData -> job_data["location"])) ? $LoadJobData -> job_data["location"] : ((isset($_POST["location"])) ? $_POST["location"] : "")) . '" name = "location" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                </div>
                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Job type *</span>
                    <select name = "job_type" class = "p-3 text-capitalize border my-2 rounded d-block w-100 outline-0">
                        ' . $LoadJobTypes -> markup(((isset($LoadJobData -> job_data["id"])) ? $LoadJobData -> job_data["id"] : ((isset($_POST["job_type"])) ? $_POST["job_type"] : ""))) . '
                    </select>
                </div>
                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Job qualifications *</span>
                    <select name = "job_qualifications" class = "p-3 text-capitalize border my-2 rounded d-block w-100 outline-0">
                        ' . $LoadJobQualifications -> markup(((isset($LoadJobData -> job_data["id"])) ? $LoadJobData -> job_data["id"] : ((isset($_POST["job_qualifications"])) ? $_POST["job_qualifications"] : ""))) . '
                    </select>
                </div>
                <div class = "col-12 mb-3">
                    <span class = "bold">Job image</span>
                    <div class = "border my-2 rounded">
                        <div>
                            <img src = "' . ((isset($LoadJobData -> job_data["image"])) ? ((file_exists("../assets/" . $LoadJobData -> job_data["image"])) ? "../assets/" . $LoadJobData -> job_data["image"] : "../assets/img/corrupt_img.png") : "../assets/img/corrupt_img.png") . '" id = "preview_img" style = "max-height: 180px;" class = "my-2 outline-0 d-block mx-auto resize-0" />
                        </div>
                        <label for = "product-image" class = "bg-light m-0 text-c d-block w-100 p-3 cursor-pointer bold text-capitalize text-secondary border-top">
                            click to select image
                            <input name = "job_img" accept = "image/*" type = "file" id = "product-image" hidden/>
                        </label>
                    </div>
                </div>
                <div class = "my-3 p-3 col-12">
                    <input type = "submit" name = "add_product" class = "p-3 text-capitalize disabled d-block w-100 theme-bg border-0 rounded shadow text-c bold text-white" value = "' . ((isset($_GET["action"])) ? "save changes" : "add job") . '"/>
                </div>
            </form>
        </div>

        <script src = "../assets/js/admin/add_product.js"></script>
    ';

    include "template/template.php";

?>
