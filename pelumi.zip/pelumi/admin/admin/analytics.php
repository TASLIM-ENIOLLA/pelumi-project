<?php

    include "../assets/php/init.php";
    include "../assets/php/processes/admin/AnalyzeProductData.php";

    $section = '
        <script>
            function donutChartData(){
                return ' . $AnalyzeProductData -> donutData() . '
            }

            function areaChartData(){
                return ' . $AnalyzeProductData -> chartData() . '
            }
        </script>
        <div class="py-4 px-3 h-100 flex-v">
            <div class="p-3 theme-color">
                <h4 class="bold text-capitalize">Analytics</h4>
            </div>
            <div class = "p-3 flex-1 overflow-y-auto">
                <div class = "py-3">
                    <h4 class = "text-capitalize theme-color bold">total number of products in stock is: <span style = "font-size: inherit;" id = "product_count"></span></h4>
                    <script>
                        document.querySelector("#product_count").innerText = new Intl.NumberFormat().format(' . $AnalyzeProductData -> product_count() . ');
                    </script>
                </div>
                <div class="row">
                    <div class="col-md-9 col-lg-6 py-2 mx-auto col-sm-12 col-xs-12">
                        <div class="panel panel-default border rounded shadom-sm">
                            <div class="panel-heading bg-light p-3 border-bottom bold text-secondary">
                                Area Chart
                            </div>
                            <div class="panel-body">
                                <div id="morris-area-chart"></div>
                            </div>
                            <div class = "bg-light bold text-secondary border-top p-3">
                                This chart gives an overview of the number of products that will expire between this current day (now) and five years to come.
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9 col-lg-6 py-2 mx-auto col-sm-12 col-xs-12">
                        <div class="panel panel-default border rounded shadom-sm">
                            <div class="panel-heading bg-light p-3 border-bottom bold text-secondary">
                                Donut Chart
                            </div>
                            <div class="panel-body">
                                <div id="morris-donut-chart"></div>
                            </div>
                            <div class = "bg-light bold text-secondary border-top p-3">
                                This chart gives a total analysis of the number of products that are valid, expiring and expired. Products within one week of expiration date are regarded as expiring products.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="../assets/js/jquery-1.10.2.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/jquery.metisMenu.js"></script>
        <script src="../assets/js/morris/raphael-2.1.0.min.js"></script>
        <script src="../assets/js/morris/morris.js"></script>
        <script src="../assets/js/admin/analytics.js"></script>
    ';

    include "template/template.php";

?>
