<?php

    $section = '
        <div class="py-4 px-3">
            <div class="p-3 theme-color">
                <h4 class="bold"><span class = "text-secondary h4">' . json_decode($_COOKIE["MP-HIRES"]) -> email_address . '</span></h4>
            </div>
            <div class="flex-h w-100 flex-wrap text-muted" style="align-items: start;">
                ' . (
                    (isset(json_decode($_COOKIE["MP-HIRES"]) -> which) && json_decode($_COOKIE["MP-HIRES"]) -> which == "employee")
                    ? '
                        <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                            <a href="all_products.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                                <div class="px-3">
                                    <span class="fa fa-2x fa-th-list"></span>
                                </div>
                                <div class="flex-h flex-1">
                                    <span class="flex-1 single-line text-capitalize bold">all jobs</span>
                                </div>
                            </a>
                        </div>
                    '
                    : ""
                ) . '
                ' . (
                    (isset(json_decode($_COOKIE["MP-HIRES"]) -> which) && json_decode($_COOKIE["MP-HIRES"]) -> which == "employer")
                    ? '
                        <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                            <a href="analytics.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                                <div class="px-3">
                                    <span class="fa fa-2x fa-bar-chart"></span>
                                </div>
                                <div class="flex-h flex-1">
                                    <span class="flex-1 single-line text-capitalize bold">analytics</span>
                                </div>
                            </a>
                        </div>
                    '
                    : ""
                ) . '

                <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                    <a href="edit_profile.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                        <div class="px-3">
                            <span class="fa fa-2x fa-user"></span>
                        </div>
                        <div class="flex-h flex-1">
                            <span class="flex-1 single-line text-capitalize bold">edit profile</span>
                        </div>
                    </a>
                </div>
                <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                    <a href="notifications.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                        <div class="px-3">
                            <span class="fa fa-2x fa-bell"></span>
                        </div>
                        <div class="flex-h flex-1">
                            <span class="flex-1 single-line text-capitalize bold">notifications</span>
                        </div>
                    </a>
                </div>
                <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                    <a href="logout.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg text-danger bg-light shadow flex-h a-i-c">
                        <div class="px-3">
                            <span class="fa fa-2x fa-power-off"></span>
                        </div>
                        <div class="flex-h flex-1">
                            <span class="flex-1 single-line text-capitalize bold">logout</span>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    ';

    include "template/template.php";

?>
