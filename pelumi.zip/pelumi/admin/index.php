<?php

    if(isset($_COOKIE['MP-HIRES'])){
        header('Location: admin/');
    }

?>
