<!DOCTYPE html>
<?php
    if(isset($_COOKIE['JOB'])){
        header('Location: ../');
    }
    else{
        include '../assets/php/init.php';
    }
?>
<html lang="en" dir="ltr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title><?= APP_NAME ?></title>
        <link rel="stylesheet" href="../assets/css/styles/index.css">
    </head>
    <body>
        <div class="w-100 h-100" id = 'main-content'>
            <div class="theme-bg p-4 text-white text-c text-uppercase bold">
                admin
            </div>
            <div class="col-10 mx-auto" style="max-width: 450px;">
                <div class="flex-h pb-2 pt-5">
                    <span class="bold text-secondary fo-s-1 text-capitalize flex-1 single-line">login</span>
                </div>
                <div id = "login" class="p-3 rounded-lg border shadow-sm border-grey pt-5">
                    <div class="mb-3">
                        <span class="text-capitalize mb-1 d-inline-block theme-color bold">user ID</span>
                        <input type="email" name = "name" id = "user_id" value = "pelumi@gmail.com" required class="shadow-sm d-block form-control w-100 p-3 border border-grey outline-0 rounded">
                    </div>
                    <div class="mb-3">
                        <span class="text-capitalize mb-1 d-inline-block theme-color bold">password</span>
                        <input type="password" name = "password" id = "password" value = "11111111" required class="shadow-sm d-block form-control w-100 p-3 border border-grey outline-0 rounded">
                    </div>
                    <div class="text-r py-3">
                        <input type="button" id = "submit-login" class="rounded bold flicker px-4 py-2 shadow theme-bg text-white border-0" value="Log In">
                    </div>
                    
                </div>
            </div>
        </div>
    </body>

    <script src = "../assets/js/Toast.js"></script>
    <script src = "../assets/js/login.js"></script>
</html>
