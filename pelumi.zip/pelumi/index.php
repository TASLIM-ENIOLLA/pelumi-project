<?php

    include "php/init.php";
    include "php/processes/components/jobs.php";
    include "php/processes/components/Testimonials.php";
    // setcookie(
    //     "MP-HIRES",
    //     null,
    //     time() + (365 * 24 * 3600)
    // );


    $more_html = '
        <!-- HOME -->
        <section id="home">
             <div class="flex-h flex-wrap">
                  <div class="owl-carousel owl-theme home-slider">
                       <div class="item item-first">
                            <div class="caption">
                                 <div class="container">
                                      <div class="col-md-6 col-sm-12">
                                           <h1>Get started with MP Hires.</h1>
                                           <h3>Login or sign up to get started.</h3>
                                           <a href="signup.php" class="section-btn btn btn-default">Sign Up</a>
                                           <a href="login.php" class="section-btn btn btn-default">Login</a>
                                      </div>
                                 </div>
                            </div>
                       </div>

                       <div class="item item-second">
                            <div class="caption">
                                 <div class="container">
                                      <div class="col-md-6 col-sm-12">
                                           <h1>Get jobs fast and easy.</h1>
                                           <h3>Our systems allows you find the best jobs easily.</h3>
                                           <a href="jobs.html" class="section-btn btn btn-default">Browse Jobs</a>
                                      </div>
                                 </div>
                            </div>
                       </div>

                       <div class="item item-third">
                            <div class="caption">
                                 <div class="container">
                                      <div class="col-md-6 col-sm-12">
                                           <h1>MP Hires is just the best</h1>
                                           <h3>We create a synergy between job seeker and job providers.</h3>
                                           <a href="jobs.html" class="section-btn btn btn-default">Browse Jobs</a>
                                      </div>
                                 </div>
                            </div>
                       </div>
                  </div>
             </div>
        </section>

        <main>
             <section>
                  <div class="container">
                       <div class="flex-h flex-wrap">
                            <div class="col-xs-12 col-md-12 col-sm-12">
                                 <div class="text-center">
                                      <h2>Search jobs</h2>

                                      <br>

                                      <div style = "border-radius: 25px;" class = "border p-0 col-xs-12 col-md-8 mx-auto overflow-0 flex-h j-c-c a-i-c">
                                        <input type = "search" id = "job_search_query" placeholder = "Search for jobs here..." style = "font-size: 15px;" class = "flex-1 border-0 h-100 outline-0 py-3 px-4" />
                                        <select id = "job_search_query_constraint" style = "max-width: 100px;" class = "p-3 outline-0 text-capitalize border mr-3">
                                            <option value = "title">name</option>
                                            <option value = "payment">salary</option>
                                            <option value = "payment_interval">interval</option>
                                            <option value = "job_category">job category</option>
                                            <option value = "job_type">job type</option>
                                            <option value = "location">location</option>
                                            <option value = "job_qualifications">job qualifications</option>
                                        </select>
                                        <input type = "submit" id = "job_search" value = "Search" name = "search_jobs" class = "py-4 bold border-0 px-4 theme-bg text-white" />
                                      </div>

                                      <div class = "pt-5 theme-color text-c bold">
                                        Your search result will be displayed here.
                                      </div>
                                      <div class = "flex-h flex-wrap" id = "job_search_result_list">

                                      </div>
                                 </div>
                            </div>
                       </div>
                  </div>
             </section>

             <section>
                  <div class="container">
                       <div class="flex-h flex-wrap">
                            <div class="col-md-12 col-sm-12">
                                 <div class="text-center">
                                      <h2>About us</h2>

                                      <br>

                                       <p class="lead">
                                          This job search tool is a place where students and the unemployed graduates converge to get a job.
                                       </p>
                                 </div>
                            </div>
                       </div>
                  </div>
             </section>

             <section>
                  <div class="container">
                       <div class="flex-h flex-wrap">
                            <div class="col-md-12 col-xs-12 col-sm-12">
                                 <div class="section-title text-c">
                                      <h2>Jobs for you<small>Browser through to see best jobs for you</small></h2>
                                 </div>
                            </div>

                            ' . $Jobs -> renderJobsForHomePage() . '
                       </div>
                  </div>
             </section>

             <section id="testimonial">
                  <div class="container">
                       <div class="row">

                            <div class="col-md-12 col-sm-12">
                                 <div class="section-title text-center">
                                      <h2>Testimonials <small>From around the world</small></h2>
                                 </div>

                                 <div class="owl-carousel owl-theme owl-client flex-h flex-wrap">
                                      <div class="col-sm-4 col-md-4">
                                           <div class="item">
                                                <div class="tst-image">
                                                     <img src="images/tst-image-1-200x216.jpg" class="img-responsive" alt="">
                                                </div>
                                                <div class="tst-author">
                                                     <h4>Jackson Janet</h4>
                                                     <span>Maintenece Officer</span>
                                                </div>
                                                <p class = "double-line">This site is authentic. I applied and got the job. It is very fast and reliable.</p>
                                                <div class="tst-rating">
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                </div>
                                           </div>
                                      </div>
                                      <div class="col-sm-4 col-md-4">
                                           <div class="item">
                                                <div class="tst-image">
                                                     <img src="images/tst-image-1-200x216.jpg" class="img-responsive" alt="">
                                                </div>
                                                <div class="tst-author">
                                                     <h4>Oguntoye Adeolu</h4>
                                                     <span>SMarketer</span>
                                                </div>
                                                <p class = "double-line">This site is authentic. I applied and got the job. It is very fast and reliable.</p>
                                                <div class="tst-rating">
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                </div>
                                           </div>
                                      </div>
                                      <div class="col-sm-4 col-md-4">
                                           <div class="item">
                                                <div class="tst-image">
                                                     <img src="images/tst-image-1-200x216.jpg" class="img-responsive" alt="">
                                                </div>
                                                <div class="tst-author">
                                                     <h4>Bashorun Taslim</h4>
                                                     <span>Graphics Instructor</span>
                                                </div>
                                                <p class = "double-line">This site is authentic. I applied and got the job. It is very fast and reliable..</p>
                                                <div class="tst-rating">
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                </div>
                                           </div>
                                      </div>
                                      <div class="col-sm-4 col-md-4">
                                           <div class="item">
                                                <div class="tst-image">
                                                     <img src="images/tst-image-1-200x216.jpg" class="img-responsive" alt="">
                                                </div>
                                                <div class="tst-author">
                                                     <h4>Obasaju Gbenga</h4>
                                                     <span>Data Analyst</span>
                                                </div>
                                                <p class = "double-line">This site is authentic. I applied and got the job. It is very fast and reliable.</p>
                                                <div class="tst-rating">
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                     <i class="fa fa-star"></i>
                                                </div>
                                           </div>
                                      </div>
                                 </div>
                           </div>
                       </div>
                  </div>
             </section>
        </main>

        <!-- CONTACT -->
        <section id="contact">
             <div class="container">
                  <div class="flex-h flex-wrap a-i-c">

                       <div class="col-xs-12 col-sm-12 col-md-6">
                            <div id="contact-form">
                                 <div class="section-title">
                                      <h2>Contact us <small>we love conversations. let us talk!</small></h2>
                                 </div>

                                 <div class="col-md-12 col-sm-12 p-0">
                                      <input type="text" id = "contact-us-fullname" class="form-control" placeholder="Enter full name" name="name" required>

                                      <input type="email" id = "contact-us-email" class="form-control" placeholder="Enter email address" name="email" required>

                                      <textarea id = "contact-us-message" class="form-control" rows="6" placeholder="Tell us about your message" name="message" required></textarea>
                                 </div>

                                 <div class="col-md-4 col-sm-12 p-0">
                                      <input type="submit" id = "contact-us-submit" class="form-control" name="send message" value="Send Message">
                                 </div>

                            </div>
                       </div>

                       <div class="col-xs-12 col-sm-12 col-md-6">
                            <!-- <div class="contact-image"> -->
                                 <img src="images/contact-1-600x400.jpg" class="d-block w-100" alt="Smiling Two Girls">
                            <!-- </div> -->
                       </div>

                  </div>
             </div>
        </section>

        <script src = "js/index.js"></script>
    ';

    include "template/template.php";

?>
