<?php

    // if(isset($_COOKIE["MP-HIRES"])){
    //     header("Location: admin/admin/");
    // }

?>
<!DOCTYPE html>
<html lang="en">
<head>

     <title>PHPJabbers.com | Free Job Agency Website Template</title>

     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link rel="stylesheet" href="css/common.css">
     <link rel="stylesheet" href="css/animate.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/style.css">

</head>
<body id="top" data-spy="scroll" class = "po-rel" data-target=".navbar-collapse" data-offset="50" style="z-index: 0;">
    <div id="mobile-menu" class="po-fixed top-0 left-0 vh100 vw100 flex-h p-0 animated d-none slideInLeft" style="background: rgba(0, 0, 0, 0.5); !important; z-index: 10000000; padding: 20px;">
        <div class = "col-xs-6 p-3 theme-bg overflow-y-auto">
            <div class = "border-bottom">
                <span id = "mobile-menu-close" class="fa p-3 text-white fa-close fa-2x"></span>
            </div>
            <div class = "border-bottom p-3">
                <a class = "d-block text-white bold py-3" href="index.php">Home</a>
                <a class = "d-block text-white bold py-3" href="job-listing.php">Jobs</a>
                <a class = "d-block text-white bold py-3" href="about-us.php">About Us</a>
                <a class = "d-block text-white bold py-3" href="contact.php">Contact Us</a>
            </div>
            <div class = "border-bottom p-3">
                <a href="login.php" class="d-block text-white py-3 bold">Login</a>
                <a href="signup.php" class="d-block text-white py-3 bold">Sign up</a>
            </div>
        </div>
    </div>

     <!-- PRE LOADER -->
     <!-- <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>
          </div>
     </section> -->

     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container-fluid j-c-space-between flex-h a-i-c">

               <div class="flex-h j-c-c a-i-c">
                    <button class="d-md-none navbar-toggle" data-toggle="collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="bold" style="font-size: 2rem;">Jobs Agency</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse flex-h d-none d-md-inherit">
                    <ul class="nav navbar-nav navbar-nav-first flex-h">
                         <li><a href="index.php">Home</a></li>
                         <li><a href="job-listing.php">Jobs</a></li>
                         <li><a href="about-us.php">About Us</a></li>
                         <li><a href="contact.php">Contact Us</a></li>
                    </ul>
               </div>

               <div class="flex-h d-none d-md-inherit">
                   <a href="login.php" style = "padding: 0px 10px;" class="d-inline-block text-success bold text-secondary">Login</a>
                   <a href="signup.php" style = "padding: 0px 10px;" class="d-inline-block text-success bold text-secondary">Sign up</a>
               </div>

          </div>
     </section>
     <script src="js/jquery.js"></script>

    <?= ((isset($more_html)) ? $more_html : "") ?>

     <!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="flex-h flex-wrap">

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Headquarter</h2>
                              </div>
                              <address>
                                   <p>Adetokunbo Cresent Wuse 2<br>FCT Abuja , PMB 123</p>
                              </address>

                              <ul class="social-icon">
                                   <li><a href="https://web.facebook.com/ifabiyi.oluwapelumi" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="https://twitter.com/MasterPe00" class="fa fa-twitter"></a></li>
                                   <li><a href="https://www.instagram.com/iammasterpee/" class="fa fa-instagram"></a></li>
                              </ul>

                              <div class="copyright-text">
                                   <p>Copyright &copy; 2021 MP Hirers</p>
                                   <p>Template by: <a href="https://www.MPHirers.com/">MPhirers.com</a></p>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Contact Info</h2>
                              </div>
                              <address>
                                   <p>+234 8181398892</p>
                                   <p><a href="mailto:contact@company.com">MPHirers@gmail.com</a></p>
                              </address>

                              <div class="footer_menu">
                                   <h2>Quick Links</h2>
                                   <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="#">Terms & Conditions</a></li>
                                        <li><a href="contact.php">Contact Us</a></li>
                                   </ul>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-12">
                         <div class="footer-info newsletter-form">
                              <div class="section-title">
                                   <h2>Newsletter Signup</h2>
                              </div>
                              <div>
                                   <div class="form-group">
                                         <input type="email" class="form-control text-white pl-0 border-bottom" placeholder="Enter your email" name="email" id="newsletter-email" required>
                                         <select id = "newsletter-qualification" name = "qualification" class = "p-3 mt-4 border outline-0 bg-clear d-block w-100 rounded text-white">
                                             <option value="graduate" selected class = "text-dark">Graduate</option>
                                             <option value="undergraduate" class = "text-dark">Undergraduate</option>
                                             <option value="student" class = "text-dark">Student</option>
                                         </select>
                                         <input type="submit" class="form-control" name="submit" id="newsletter-form-submit" value="Send me">
                                        <span><sup>*</sup> Please note - we do not spam your email.</span>
                                   </div>
                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </footer>

     <!-- SCRIPTS -->

     <script src="js/bootstrap.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/toast.js"></script>
     <script src="js/custom.js"></script>

</body>
</html>
