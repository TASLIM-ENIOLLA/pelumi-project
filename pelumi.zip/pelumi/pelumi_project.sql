-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2022 at 07:04 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pelumi_project`
--
CREATE DATABASE IF NOT EXISTS `pelumi_project` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pelumi_project`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` varchar(20) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `profile_img` varchar(50) DEFAULT NULL,
  `priviledge` varchar(20) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `f_name`, `l_name`, `mobile_number`, `email`, `password`, `profile_img`, `priviledge`, `date_created`) VALUES
('7vaisxe9hg2fu293y86c', 'pelumi', 'akorede', '+234 88888888', 'pelumi@gmail.com', '1bbd886460827015e5d605ed44252251', 'img/admin/7vaisxe9hg2fu293y86c/lxrzkl80uo.png', 'priv-qh8ty', '2021-12-07 11:39:22');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `author` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `author`, `description`, `timestamp`) VALUES
('1', 'banking', '1', 'Money related stuffs', '2022-01-14 11:45:03'),
('2', 'IT', '1', 'all about the bits', '2022-01-14 11:45:03');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` varchar(20) NOT NULL,
  `f_name` int(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `location` tinytext NOT NULL,
  `password` varchar(50) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `f_name`, `l_name`, `phone_number`, `location`, `password`, `email_address`, `timestamp`) VALUES
('emp-potv3in4vmd9d1ew', 0, 'gfgdg', '57687', 'FSDHGJDR', '1bbd886460827015e5d605ed44252251', 'agrer@fjkgd.com', '2022-01-15 17:53:21');

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE `employer` (
  `id` varchar(20) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `location` tinytext NOT NULL,
  `password` varchar(50) NOT NULL,
  `CAC_number` int(11) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employer`
--

INSERT INTO `employer` (`id`, `company_name`, `phone_number`, `location`, `password`, `CAC_number`, `email_address`, `timestamp`) VALUES
('emp-2wq26v2izb5p9iza', 'dgfah', '4675875', 'efgrfe', '1bbd886460827015e5d605ed44252251', 536567, 'agrer@fjkgd.com', '2022-01-15 17:42:44'),
('emp-bvho6xkavg466fk5', 'dvgf', '4675875', 'FDGDHG', '1bbd886460827015e5d605ed44252251', 4736, 'agrer@fjkgd.com', '2022-01-15 17:31:21'),
('emp-ia1dkkaipyof9l1y', 'fhsgj', '4675875', 'efgrfe', '1bbd886460827015e5d605ed44252251', 5675, 'agrer@fjkgd.com', '2022-01-15 17:36:06'),
('emp-y8kgmkhvuu044gkm', 'dvgf', '4675875', 'FDGDHG', '1bbd886460827015e5d605ed44252251', 4736, 'agrer@fjkgd.com', '2022-01-15 17:32:37'),
('emp-z0fsnezhgiqgrtyu', 'sagD', '452675', 'DG', '1bbd886460827015e5d605ed44252251', 4365, '562GFASBA@gmail.cpm', '2022-01-15 17:29:23');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` varchar(20) NOT NULL,
  `title` varchar(60) NOT NULL,
  `payment` int(11) NOT NULL,
  `payment_interval` varchar(10) NOT NULL,
  `job_category` varchar(50) NOT NULL,
  `location` text NOT NULL,
  `job_type` varchar(100) NOT NULL,
  `job_description` text NOT NULL,
  `job_responsibilities` text NOT NULL,
  `job_qualifications` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `payment`, `payment_interval`, `job_category`, `location`, `job_type`, `job_description`, `job_responsibilities`, `job_qualifications`, `image`, `timestamp`) VALUES
('job-8gnp7ui8hpzdau69', 'Farmer', 5689, 'weekly', 'banking', 'gkjfkgf hgckhvcgj kjkc', 'accountant', 'name', 'name', 'ND/HND', 'img/jobs/1642527619.png', '2022-01-18 17:40:19'),
('job-pa8gypomt1ipbcvc', 'grkjb', 4368959, 'weekly', 'banking', 'FGGFJFH BKJUB', 'accountant', 'ND\r\nSSCE/GCE\r\nFirst Degree', 'ND\r\nSSCE/GCE\r\nFirst Degree', '3', 'img/jobs/1642527230.jpg', '2022-01-18 17:33:50'),
('job-xmrko2shbh4knyg6', 'Teacher', 489134, 'monthly', 'banking', 'gkjfkgf hgckhvcgj kjkc', 'accountant', 'name', 'name', 'undergraduate', 'img/jobs/1642527506.png', '2022-01-18 17:38:26');

-- --------------------------------------------------------

--
-- Table structure for table `qualifications`
--

CREATE TABLE `qualifications` (
  `id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `author` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qualifications`
--

INSERT INTO `qualifications` (`id`, `name`, `author`, `description`, `timestamp`) VALUES
('1', 'undergraduate', '1', '', '2022-01-14 11:50:32'),
('2', 'graduate', '1', '', '2022-01-14 11:50:32'),
('3', 'GCE/SSCE', '1', '', '2022-01-14 11:51:07'),
('4', 'ND/HND', '1', '', '2022-01-14 11:51:07');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `author` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `name`, `author`, `description`, `timestamp`) VALUES
('1', 'accountant', '1', '', '2022-01-14 11:48:08'),
('2', 'frontend developer', '1', '', '2022-01-14 11:48:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qualifications`
--
ALTER TABLE `qualifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
