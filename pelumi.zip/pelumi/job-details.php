<?php

    include "php/init.php";
    include "php/processes/components/job_details.php";

    if($JobDetails -> job_info != NULL){
        $more_html = '
            <section>
                 <div class="container">
                      <div class="row">
                           <div class="col-lg-3 col-md-3 col-xs-12">
                                <div>
                                     <br>
                                     <img src="' . (
                                            (file_exists("admin/assets/" . $JobDetails -> job_info["image"]))
                                            ? "admin/assets/" . $JobDetails -> job_info["image"]
                                            : "admin/assets/img/default.png"
                                        ) . '" alt="" class="img-responsive border rounded wc-image">
                                     <br>
                                </div>
                           </div>
                           <div class="col-lg-9 col-md-9 col-xs-12">
                                <form action="#" method="post" class="form">
                                    <h2>' . $JobDetails -> job_info["title"] . '</h2>
                                    <p class="lead">₦' . number_format($JobDetails -> job_info["payment"]) . " " . $JobDetails -> job_info["payment_interval"] . '</p>
                                    <p class="lead text-capitalize">
                                        <i class="fa fa-briefcase"></i> '. $JobDetails -> job_info["job_type"] . ' &nbsp;&nbsp;
                                        <i class="fa fa-map-marker"></i> '. $JobDetails -> job_info["location"] . ' &nbsp;&nbsp;
                                        <i class="fa fa-calendar"></i> '. date("Y-m-d", strtotime($JobDetails -> job_info["timestamp"])) . ' &nbsp;&nbsp;
                                    </p>
                                </form>
                           </div>
                      </div>
                      <div class="panel panel-default">
                           <div class="panel-heading">
                                <h4>Job Info</h4>
                           </div>
                           <div class="panel-body">
                                <h4>Description:</h4>
                                <p>
                                    '. $JobDetails -> job_info["job_description"] . '
                                </p>
                                <h4>Responsibillitites:</h4>
                                <p>
                                    '. $JobDetails -> job_info["job_responsibilities"] . '
                                </p>
                                <h4>Qualifications:</h4>
                                <p>
                                    '. $JobDetails -> job_info["job_qualifications"] . '
                                </p>
                                <!-- <p>- MUST have minimum 1 year experience in RETAIL security (shops).</p>
                                <p>- MUST be Fluent in the English Language (speaking and writing).</p>
                                <p>- MUST hold a valid SIA Door Supervisor Licence.</p> -->
                           </div>
                      </div>
                      <div class="panel panel-default">
                           <div class="panel-heading text-capitalize">
                                <h4>About '. $JobDetails -> job_info["company_name"] . '</h4>
                           </div>
                           <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p>
                                            <span>Company name</span>
                                            <br>
                                            <strong>'. $JobDetails -> job_info["company_name"] . '</strong>
                                        </p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p>
                                            <span>Phone</span>
                                            <br>
                                            <strong><a href="'. $JobDetails -> job_info["phone_number"] . '">'. $JobDetails -> job_info["phone_number"] . '</a></strong>
                                        </p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p>
                                            <span>Email</span>
                                            <br>
                                            <strong><a href="mailto:'. $JobDetails -> job_info["email_address"] . '">'. $JobDetails -> job_info["email_address"] . '</a></strong>
                                        </p>
                                    </div>
                                </div>
                                <p>
                                    <span>Location</span>
                                    <br>
                                    <strong>'. $JobDetails -> job_info["location"] . '</strong>
                                </p>
                           </div>
                      </div>

                      <div class="clearfix">
                           <a href="#" class="section-btn btn btn-primary pull-left">Apply for this job</a>
                      </div>
                 </div>
            </section>
        ';
    }
    else{
        $more_html = '
            <div class = "p-5 bg-danger col-xs-9 mx-auto my-5 rounded bold text-secondary text-c">
                Failed to retrieve job info.
            </div>
        ';
    }

    include "template/template.php";

?>
