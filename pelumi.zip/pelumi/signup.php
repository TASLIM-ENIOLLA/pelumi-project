<?php

    include "php/init.php";


    $more_html = '
        <div class = "py-5 px-3">
            <div class = "text-c flex-h a-i-c">
                <span class = "flex-1 single-line bold h4 theme-color">Sign up</span>
            </div>
            <div class = "py-5 col col-md-7 col-lg-8 mx-auto">
                <!-- <form id = "signup-form" method = "POST" action = "" style = "border-radius: 10px;" class = "border flex-h flex-wrap shadow bg-white px-4 py-5">
                    <div class = "col-xs-12 px-2">
                        <div id = "error-pane" class = "rounded d-none p-4 bold my-3 mx-4 bg-danger text-secondary">
                            An error occured!
                        </div>
                    </div>
                    <div class = "col-xs-12 px-3 mb-3 flex-h theme-color tab-toggle">
                        <div id = "employer-tab" class = "border-0 cursor-pointer flex-1 text-center bold text-capitalize active-menu border-bottom mx-3 py-3">employer</div>
                        <div id = "employee-tab" class = "border-0 cursor-pointer flex-1 text-center bold text-capitalize border-bottom mx-3 py-3">employee</div>
                    </div>
                    <div class = "py-3 mb-3 col-md-6 col-xs-12 employers">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">company name</span>
                        </span>
                        <input name = "company_name" type = "text" class = "p-3 border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-3 mb-3 col-md-6 col-xs-12 employers">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">CAC number</span>
                        </span>
                        <input name = "CAC_number" type = "number" class = "p-3 border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-3 mb-3 col-md-6 col-xs-12 employees d-none">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">First name</span>
                        </span>
                        <input name = "f_name" type = "text" class = "p-3 border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-3 mb-3 col-md-6 col-xs-12 employees d-none">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">Last name</span>
                        </span>
                        <input name = "l_name" type = "text" class = "p-3 border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-3 mb-3 col-md-6 col-xs-12">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">email address</span>
                        </span>
                        <input name = "email_address" type = "email" class = "p-3 border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-3 mb-3 col-md-6 col-xs-12">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">phone number</span>
                        </span>
                        <input name = "phone_number" type = "phone" class = "p-3 border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-3 mb-3 col-md-6 col-xs-12">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">location</span>
                        </span>
                        <input name = "location" type = "text" class = "p-3 border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-3 mb-3 col-md-6 col-xs-12">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">password</span>
                        </span>
                        <input name = "password" type = "password" class = "p-3 border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-3 mb-3 col-md-6 col-xs-12">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">confirm password</span>
                        </span>
                        <input name = "c_password" type = "password" class = "p-3 border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-2 mb-3 col-12 px-4">
                        <label for = "agreement">
                            <input name = "agreement" id = "agreement" value = "agreed" type = "checkbox" class = "p-3 border outline-0 rounded" />
                            <span class = "text-capitalize bold theme-color">By checking this box, you agree to our terms and policies.</span>
                        </label>
                    </div>
                    <input type = "hidden" name = "which" value = "employer" hidden/>
                    <div class = "py-3 mb-3 px-4" style = "width: 100%;">
                        <button name = "submit" value = "" type = "submit" class = "p-3 outline-0 flicker rounded theme-bg text-white border-0 bold d-block w-100">Sign Up</button>
                    </div>
                </form> -->
            </div>
        </div>

        <script src = "js/user/signup.js"></script>
    ';

    include "template/template.php";

?>
