<?php

    include "php/init.php";
    include "php/processes/login/login.php";


    $verification_message = (
        (isset($verification_message))
        ? '
            <div style = "border-radius: 5px;" class = "mb-3 text-c bg-danger py-4 px-3 text-secondary bold">
                ' . $verification_message . '
            </div>
        '
        : ''
    );

    $more_html = '
        <div class = "py-5 px-3">
            <div class = "text-c flex-h j-c-c a-i-c">
                <span class = "flex-1 single-line bold h4 theme-color">Login</span>
            </div>
            <div class = "py-5 col col-md-7 col-lg-5 mx-auto" style = "max-width: 400px; margin: auto;">
                <form
                    action = ""
                    method = "POST"
                    class = "px-4 py-5" style = "border-radius: 10px; box-shadow: 0px 2px 5px #186e4e54;">
                    <div>
                        ' . $verification_message . '
                    </div>
                    <div id = "cac_number" class = "py-3 mb-3">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">CAC number</span>
                        </span>
                        <input type = "text" name = "cac_number" value = "' . (isset($_POST["cac_number"]) ? $_POST["cac_number"] : "") . '" class = "p-3 theme-color border outline-0 rounded d-block w-100" />
                    </div>
                    <div id = "email_address" class = "py-3 mb-3 d-none">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">email address</span>
                        </span>
                        <input type = "text" value = "' . (isset($_POST["email_address"]) ? $_POST["email_address"] : "") . '" name = "email_address" class = "p-3 theme-color border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-3 mb-3">
                        <span class = "flex-h mb-3">
                            <span class = "flex-1 single-line text-capitalize bold theme-color">password</span>
                        </span>
                        <input type = "password" name = "password" class = "p-3 theme-color border outline-0 rounded d-block w-100" />
                    </div>
                    <div class = "py-3 mb-3 theme-color text-capitalize flex-h">
                        <label class = "flex-1">
                            <input checked type = "radio" value = "employer" name = "which" class = "p-3 theme-color border outline-0 rounded" />
                            employer
                        </label>
                        <label class = "flex-1">
                            <input type = "radio" value = "employee" name = "which" class = "p-3 theme-color border outline-0 rounded" />
                            employee
                        </label>
                    </div>
                    <div class = "py-3 mb-3">
                        <input
                            style = "border-radius: 10px; box-shadow: 0px 2px 5px #186e4e54;"
                            value = "Login"
                            type = "submit"
                            name = "login"
                            class = "p-3 outline-0 flicker rounded theme-bg text-white border-0 bold flicker d-block w-100" />
                    </div>
                </form>
            </div>
        </div>

        <script src = "js/user/login.js"></script>
    ';

    include "template/template.php";

?>
