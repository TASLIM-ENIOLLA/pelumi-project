document.querySelectorAll(".tab-toggle > div").forEach(
	item => {
		item.onclick = (e) => {
			document.querySelectorAll(".tab-toggle > div").forEach(
				i => {
					i.classList.remove("active-menu");
				}
			);

			item.classList.add("active-menu");

			if(item.id == "employer-tab"){
				document.querySelectorAll(".employers").forEach(
					item => {
						item.classList.remove("d-none");
					}
				);
				document.querySelectorAll(".employees").forEach(
					item => {
						item.classList.add("d-none");
					}
				);

				document.querySelector("[type = 'hidden']").value = "employer";
			}
			else{
				document.querySelectorAll(".employers").forEach(
					item => {
						item.classList.add("d-none");
					}
				);
				document.querySelectorAll(".employees").forEach(
					item => {
						item.classList.remove("d-none");
					}
				);

				document.querySelector("[type = 'hidden']").value = "employee";
			}
		}
	}
);

document.querySelector("#signup-form").onsubmit = (e) => {
	e.preventDefault();
	if(document.querySelector("#agreement").checked){
		let formData = new FormData();

		document.querySelectorAll("#signup-form input").forEach(
			item => {
				formData.append(item.name, item.value);
			}
		);

		let xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = () => {
			if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
				console.log(xmlhttp.responseText);
				let responseText =  xmlhttp.responseText;
				if(responseText == "success"){
					window.location.replace("admin/");
				}
				else{
					document.querySelector("#error-pane").classList.remove("d-none");
					document.querySelector("#error-pane").innerHTML = responseText;
				}
			}
		}
		xmlhttp.open(
			"POST",
			"php/processes/signup/signup.php"
		);
		xmlhttp.send(formData)
	}
	else{
		document.querySelector("#error-pane").classList.remove("d-none");
		document.querySelector("#error-pane").innerHTML = "You have to accept our terms and agreements to proceed.";
	}
}