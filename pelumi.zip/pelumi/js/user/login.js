document.querySelector('input[value = "employer"]').addEventListener(
	"input",
	(e) => {
		document.querySelector("#cac_number").classList.remove("d-none");
		document.querySelector("#email_address").classList.add("d-none");
	}
);

document.querySelector('input[value = "employee"]').addEventListener(
	"input",
	(e) => {
		document.querySelector("#cac_number").classList.add("d-none");
		document.querySelector("#email_address").classList.remove("d-none");
	}
);
