document.querySelector("#job_search").addEventListener(
    "click",
    run_job_search
);

document.querySelector("#job_search_query").addEventListener(
    "input",
    run_job_search
);

document.querySelector("#job_search_query_constraint").addEventListener(
    "input",
    run_job_search
);

function run_job_search(){
    let job_search_query = document.querySelector("#job_search_query");
    let job_search_query_constraint = document.querySelector("#job_search_query_constraint");

    if(job_search_query.value.length > 0){
        job_search_result_list.classList.add("pt-5");
        fetch(
            "php/processes/components/search_jobs.php?job_search_query="
            + job_search_query.value
            + "&job_search_query_constraint="
            + job_search_query_constraint.value
        ).then(e => e.json()).then(
            responseJSON => {
                console.log(responseJSON);
                let job_search_result_list = document.querySelector("#job_search_result_list");
                job_search_result_list.innerHTML = "";

                if(responseJSON.length > 0){
                    for(let index in responseJSON){
                        item = responseJSON[index];
                        let a = document.createElement("div");
                        a.className = "animated fadeIn p-3 col-xs-12 col-md-6 mb-3 flex-h cursor-pointer flicker transit"
                        a.style="animation-delay: 0.1s;";
                        a.setAttribute("data-id", item.id)
                        a.setAttribute("data-name", item.title)
                        a.setAttribute("data-category", item.job_category)
                        a.setAttribute("data-type", item.job_type)
                        a.setAttribute("data-location", item.location)
                        a.setAttribute("data-payment", item.payment)
                        a.setAttribute("data-payment-interval", item.payment_interval);
                        job_search_result_list.appendChild(a);
                        {
                            let b = document.createElement("a");
                            b.href = "job-details.php?job_id=" + item.id;
                            b.className = "flex-h border rounded w-100 overflow-0";
                            a.appendChild(b);
                            {
                                let c = document.createElement("div");
                                c.style = "width: 120px; height: 120px; background: url(admin/assets/" + item.image + "); background-size: cover; background-position: center;";
                                b.appendChild(c);

                                let d = document.createElement("div");
                                d.className = "flex-1 text-l text-muted p-3";
                                d.style = "background: #f8f8f8;";
                                b.appendChild(d);
                                {
                                    let e = document.createElement("div");
                                    e.className = "bold one-line mt-1 text-capitalize";
                                    e.innerHTML = item.title;
                                    d.appendChild(e);

                                    let f = document.createElement("div");
                                    f.className = "text-capitalize one-line mt-1";
                                    f.innerHTML = "₦" + new Intl.NumberFormat().format(item.payment) + " " + item.payment_interval;
                                    d.appendChild(f);

                                    let g = document.createElement("div");
                                    g.className = "text-capitalize one-line mt-1";
                                    g.innerHTML = "Sector: " + item.job_category;
                                    d.appendChild(g);

                                    let h = document.createElement("div");
                                    h.className = "text-capitalize one-line mt-1";
                                    h.innerHTML = "Location: " + item.location;
                                    d.appendChild(h);

                                    let i = document.createElement("div");
                                    i.className = "text-capitalize one-line mt-1";
                                    i.innerHTML = "Posted: " + item.timestamp;
                                    d.appendChild(i);

                                }
                            }
                        }
                    }
                }
                else{
                    let a = document.createElement("div");
                    a.className = "p-5 border bold text-c col-xs-10 mx-auto rounded text-secondary";
                    a.style = "background: #f8f8f8;";
                    a.innerHTML = "No job found!";
                    job_search_result_list.appendChild(a);
                }
            }
        );
    }
    else{
        job_search_result_list.classList.remove("pt-5");
        job_search_result_list.innerHTML = "";
    }
}

$("#contact-us-submit").on(
    "click",
    (e) => {
        $.post(
            "php/processes/contact_us/contact_us.php", {
                fullname : $("#contact-us-fullname").val(),
                email    : $("#contact-us-email").val(),
                message  : $("#contact-us-message").val()
            },
            (data, status) => {
                if(status == "success" && data == "success"){
                    toast("Your contact has been saved. We'll surely get back!", "primary");
                }
                else{
                    toast("Something went wrong! Try again.", "danger");
                }
            }
        );
    }
);
