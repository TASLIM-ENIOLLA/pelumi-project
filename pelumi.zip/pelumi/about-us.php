<?php

     include "php/init.php";
     include "php/processes/components/jobs.php";


     $more_html = '
          <section>
               <div class="container">
                    <div class="text-center">
                         <h1>About Us</h1>

                         <br>

                         <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo, alias.</p>
                    </div>
               </div>
          </section>

          <section class="section-background">
               <div class="container">
                    <div class="flex-h flex-wrap">
                         <div class="col-md-7 col-xs-12">
                              <div class="about-info">
                                   <h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur, eos. Corporis, dolor?</h2>

                                   <figure>
                                        <figcaption>
                                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus, deserunt beatae praesentium veniam. Aperiam assumenda quas qui officiis, minima laudantium?</p>

                                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis saepe quos repellat eum tempore magnam molestiae. Minus atque, aliquid assumenda, vero non recusandae illum optio, sint dignissimos praesentium ducimus repudiandae eius, nulla. Pariatur magnam alias est voluptatibus distinctio voluptate culpa, iste quisquam! Iure itaque rerum sequi, tenetur voluptatibus nihil quaerat, quisquam non in autem ducimus tempore impedit. Odit, corporis, praesentium.</p>
                                        </figcaption>
                                   </figure>
                              </div>
                         </div>
                         <div class="col-md-4 col-xs-12">
                              <img src="images/about-1-720x720.jpg" style = "max-width: 500px;" class="img-responsive mx-auto d-block w-100 img-circle" alt="">
                         </div>
                    </div>
               </div>
          </section>

          <section class="">
               <div class="container">
                    <div class="flex-h flex-wrap">
                         <div class="col-md-4 col-xs-12 p-3 mx-2">
                              <img src="images/about-1-720x720.jpg" style = "max-width: 500px;" class="mx-auto d-block w-100 img-circle" alt="">
                         </div>
                         <div class="col-md-7 col-xs-12 p-3 mx-2">
                              <div class="about-info">
                                   <h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur, eos. Corporis, dolor?</h2>

                                   <figure>
                                        <figcaption>
                                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus, deserunt beatae praesentium veniam. Aperiam assumenda quas qui officiis, minima laudantium?</p>

                                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis saepe quos repellat eum tempore magnam molestiae. Minus atque, aliquid assumenda, vero non recusandae illum optio, sint dignissimos praesentium ducimus repudiandae eius, nulla. Pariatur magnam alias est voluptatibus distinctio voluptate culpa, iste quisquam! Iure itaque rerum sequi, tenetur voluptatibus nihil quaerat, quisquam non in autem ducimus tempore impedit. Odit, corporis, praesentium.</p>
                                        </figcaption>
                                   </figure>
                              </div>
                         </div>
                    </div>
               </div>
          </section>
          
          <section class="section-background">
               <div class="container">
                    <div class="row">
                         <div class="col-md-12 col-sm-12">
                              <div class="text-center">
                                   <h2>Lorem ipsum dolor sit amet</h2>

                                   <br>

                                   <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore molestias ipsa veritatis nihil iusto maiores natus dolor, a reiciendis corporis obcaecati ex. Totam assumenda impedit aut eum, illum distinctio saepe explicabo. Consequuntur molestiae similique id quos, quasi quas perferendis laboriosam, fugit natus odit totam! Id dolores saepe, sint debitis rerum dolorem tempora aliquid, pariatur enim nisi. Quia ab iusto assumenda.</p>
                              </div>
                         </div>
                    </div>
               </div>
          </section>
     ';

     include "template/template.php";

?>