<?php

     include "php/init.php";
     include "php/processes/components/jobs.php";


     $more_html = '
          <section>
               <div class="container">
                    <div class="text-center">
                         <h1>Contact Us</h1>

                         <br>

                         <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo, alias.</p>
                    </div>
               </div>
          </section>


          <!-- CONTACT -->
          <section id="contact">
               <div class="container">
                    <div class="flex-h flex-wrap">
                         <div class="col-md-6 col-xs-12 col-sm-12">
                              <div id="contact-form">
                                   <div class="col-md-12 col-sm-12">
                                        <input type="text" id = "contact-us-fullname" class="form-control" placeholder="Enter full name" name="name" required>

                                        <input type="email" id = "contact-us-email" class="form-control" placeholder="Enter email address" name="email" required>

                                        <textarea id = "contact-us-message" class="form-control" rows="6" placeholder="Tell us about your message" name="message" required></textarea>
                                   </div>

                                   <div class="col-md-4 col-sm-12">
                                        <input type="submit" id = "contact-us-submit" class="form-control" name="send message" value="Send Message">
                                   </div>

                              </div>
                         </div>

                         <div class="col-md-6 col-xs-12 col-sm-12">
                              <div class="contact-image">
                                   <img src="images/contact-1-600x400.jpg" class="img-responsive mx-auto" alt="">
                              </div>
                         </div>

                    </div>
               </div>
          </section>

          <script>
              $("#contact-us-submit").on(
                  "click",
                  (e) => {
                      $.post(
                          "php/processes/contact_us/contact_us.php", {
                              fullname : $("#contact-us-fullname").val(),
                              email    : $("#contact-us-email").val(),
                              message  : $("#contact-us-message").val()
                          },
                          (data, status) => {
                              if(status == "success" && data == "success"){
                                  toast("Your contact has been saved. We\'ll surely get back!", "primary");
                              }
                              else{
                                  toast("Something went wrong! Try again.", "danger");
                              }
                          }
                      );
                  }
              );

          </script>
     ';

     include "template/template.php";

?>
